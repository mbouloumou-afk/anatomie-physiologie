/**
 * Données exhaustives du cours "Anatomie et Physiologie Humaine"
 * Université Mohammed VI des Sciences et de la Santé (UM6SS)
 * Faculté Mohammed VI des Sciences Infirmières et des Professions de la Santé - Marrakech
 * Filière: SI/RR - Options: IP / IAR / IBO / KINE - Semestre 1
 * Professeur: Dr BADRAOUI Marouane (2026-2027)
 */

export interface SystemInfo {
  id: string;
  name: string;
  iconName: string;
  category: string;
  organs: string[];
  mainFunction: string;
  physiologicalRole: string;
  clinicalRelevance: string;
  interdependence: string;
  color: string;
}

export interface OrganelleInfo {
  id: string;
  name: string;
  frenchSubtitle: string;
  structure: string;
  function: string;
  details: string[];
  courseNote?: string;
  color: string;
}

export interface TissueInfo {
  id: string;
  name: string;
  description: string;
  examples: string[];
  subtypes?: { name: string; description: string }[];
  location: string;
  role: string;
  color: string;
}

export const COURSE_METADATA = {
  university: "Université Mohammed VI des Sciences et de la Santé (UM6SS)",
  faculty: "Faculté Mohammed VI des Sciences Infirmières et Professions de la Santé - Marrakech",
  module: "Anatomie et physiologie humaine",
  filiere: "SI / RR (Sciences Infirmières / Rééducation et Réhabilitation)",
  options: "IP - IAR - IBO - KINE (Infirmier Polyvalent, Anesthésie-Réanimation, Bloc Opératoire, Kinésithérapie)",
  semester: "Semestre 1",
  professor: "Dr BADRAOUI Marouane",
  professorTitle: "Ancien professeur assistant à la faculté de médecine et de pharmacie, Enseignant à l'ISPITS Marrakech, Enseignant vacataire à l'UM6SS",
  academicYear: "2026-2027",
  objectives: [
    "Compréhension du corps humain dans sa globalité : reconnaître les différentes parties et les différents systèmes",
    "Acquisition et maîtrise des termes anatomiques et physiologiques fondamentaux",
    "Assimilation de la structure cellulaire eucaryote, des échanges membranaires et du cycle cellulaire",
    "Compréhension de l'organisation hiérarchique : de la cellule aux tissus, organes et systèmes intégrés"
  ]
};

export const IMAGES = {
  hero: "/src/assets/images/anatomy_hero_3d_1791055651429.jpg",
  cell: "/src/assets/images/cell_3d_structure_1791055663514.jpg",
  tissues: "/src/assets/images/tissues_microscopy_1791055673966.jpg",
  stomach: "/src/assets/images/stomach_tissue_layers_1791055684331.jpg",
  realCellTem: "/src/assets/images/photo_cell_tem_micrograph_1791056201508.jpg",
  realHeart: "/src/assets/images/photo_heart_cardiac_specimen_1791056214450.jpg",
  realLungs: "/src/assets/images/photo_lungs_alveoli_histology_1791056224857.jpg",
  realSkin: "/src/assets/images/photo_skin_integument_histology_1791056235260.jpg",
  realBrain: "/src/assets/images/photo_brain_neuroanatomy_specimen_1791056247134.jpg",
};

export const REAL_PHOTOS_GALLERY = [
  {
    id: "tem_cell",
    title: "Microscopie Électronique à Transmission (TEM)",
    subject: "Cellule Eucaryote Humaine",
    description: "Vraie photographie au microscope électronique révélant la double membrane nucléaire à pores, les crêtes des mitochondries et les saccules bordées de ribosomes du RE granuleux.",
    image: "/src/assets/images/photo_cell_tem_micrograph_1791056201508.jpg",
    magnification: "x 45 000 (Ultrastructure)",
    slideRef: "Slides 7 à 18 : La Cellule et ses organites"
  },
  {
    id: "real_heart",
    title: "Pièce Anatomique Cardiaque Réelle",
    subject: "Cœur Humain & Myocarde",
    description: "Photographie médicale authentique du cœur humain montrant les cavités ventriculaires, la crosse de l'aorte, les artères coronaires et le tissu musculaire strié cardiaque.",
    image: "/src/assets/images/photo_heart_cardiac_specimen_1791056214450.jpg",
    magnification: "Échelle Macro 1:1",
    slideRef: "Slide 34 : Système cardio-vasculaire"
  },
  {
    id: "real_lungs",
    title: "Histopathologie Pulmonaire Réelle",
    subject: "Alvéoles & Barrière Alvéolo-Capillaire",
    description: "Vraie lame histologique optique montrant les sacs alvéolaires tapissés par l'épithélium pavimenteux simple et le riche réseau de capillaires sanguins assurant l'hématose (diffusion O2/CO2).",
    image: "/src/assets/images/photo_lungs_alveoli_histology_1791056224857.jpg",
    magnification: "x 400 (Microscopie optique)",
    slideRef: "Slide 33 : Système respiratoire"
  },
  {
    id: "real_brain",
    title: "Spécimen Neuro-anatomique Réel",
    subject: "Encéphale & Hémisphères Cérébraux",
    description: "Photographie médicale réelle de l'encéphale humain montrant la substance grise du cortex, les circonvolutions (gyri), les sillons (sulci), le cervelet et le tronc cérébral.",
    image: "/src/assets/images/photo_brain_neuroanatomy_specimen_1791056247134.jpg",
    magnification: "Échelle Réelle (SNC)",
    slideRef: "Slide 37 : Système nerveux central"
  },
  {
    id: "real_skin",
    title: "Coupe Histologique Réelle de la Peau",
    subject: "Système Tégumentaire",
    description: "Vraie photographie microscopique montrant la stratification de l'épiderme kératinisé, le derme riche en collagène, le follicule pileux avec sa glande sébacée et son muscle horripilateur.",
    image: "/src/assets/images/photo_skin_integument_histology_1791056235260.jpg",
    magnification: "x 200 (Coloration H&E)",
    slideRef: "Slide 40 : Système tégumentaire"
  },
  {
    id: "stomach_histology",
    title: "Dissection et Histologie de l'Organe",
    subject: "Coupe des 4 Tuniques de l'Estomac",
    description: "Photographie anatomique et histologique de la paroi gastrique illustrant la muqueuse sécrétoire d'acide HCl, la sous-muqueuse vasculaire et les 3 faisceaux musculaires lisses de brassage.",
    image: "/src/assets/images/stomach_tissue_layers_1791055684331.jpg",
    magnification: "Coupe transversale 3D",
    slideRef: "Slide 30 : L'Organe (exemple de l'estomac)"
  }
];

export const DEFINITIONS = {
  anatomie: {
    title: "Anatomie",
    definition: "Étude de la forme et de la structure du corps, de ses parties et des relations qu'elles ont les unes avec les autres.",
    etymology: "Du grec 'ana' (à travers) et 'tomē' (coupe / dissection)",
    focus: "Morphologie statique, rapports spatiaux, topographie et constitution des structures corporelles."
  },
  physiologie: {
    title: "Physiologie",
    definition: "Étude du fonctionnement du corps et de ses parties, c'est-à-dire de la façon dont celles-ci jouent leurs rôles.",
    etymology: "Du grec 'physis' (nature) et 'logos' (discours, étude)",
    focus: "Mécanismes dynamiques, régulation homéostasique, échanges physico-chimiques et coordination systémique."
  }
};

export const HIERARCHY_LEVELS = [
  {
    level: 1,
    id: "cellule",
    title: "La Cellule",
    count: "100 000 milliards",
    scale: "10 à 100 µm",
    definition: "Unité fondamentale, structurale et fonctionnelle de tous les organismes vivants.",
    description: "L'être humain est un organisme eucaryote car ses cellules possèdent un noyau bien défini et des organites compartimentés par des membranes."
  },
  {
    level: 2,
    id: "tissu",
    title: "Le Tissu",
    count: "4 grands groupes",
    scale: "0.1 à 5 mm",
    definition: "Ensemble de cellules spécialisées et adaptées à une même fonction.",
    description: "Exemple : le tissu musculaire est un ensemble de cellules (myocytes) partageant la capacité de se contracter et de se relâcher pour assurer le mouvement."
  },
  {
    level: 3,
    id: "organe",
    title: "L'Organe",
    count: "~78 organes",
    scale: "1 à 30 cm",
    definition: "Ensemble de tissus différents associés en vue d'assurer une même fonction complexe.",
    description: "Exemple : l'estomac associe le tissu épithélial (muqueuse), le tissu musculaire lisse (brassage), le tissu conjonctif (soutien/vaisseaux) et le tissu nerveux (plexus myentérique)."
  },
  {
    level: 4,
    id: "systeme",
    title: "L'Appareil / Système",
    count: "10 systèmes majeurs",
    scale: "Organisme entier",
    definition: "Ensemble d'organes associés en vue d'assurer une grande fonction vitale.",
    description: "Exemples : système digestif, respiratoire, circulatoire, urinaire, locomoteur, nerveux, endocrinien..."
  },
  {
    level: 5,
    id: "organisme",
    title: "L'Organisme Humain",
    count: "1 être vivant complet",
    scale: "1.5 à 1.9 m",
    definition: "Organisme extrêmement complexe où aucun système ne travaille de façon isolée : ils collaborent tous au bien-être et à l'homéostasie.",
    description: "Un mécanisme évolué d'organisation et de fonctionnement où l'intégration globale assure la vie."
  }
];

export const ORGANELLES: OrganelleInfo[] = [
  {
    id: "noyau",
    name: "Noyau Cellulaire",
    frenchSubtitle: "Le plus volumineux des organites cellulaires",
    structure: "Enveloppe nucléaire double percée de pores, nucléoplasme gélatineux, nucléole riche en ARN et protéines, chromatine (ADN + histones).",
    function: "Centre de commande génétique : dirige et coordonne toutes les activités cellulaires, contrôle la synthèse protéique, détient le génome héréditaire.",
    details: [
      "Enveloppe nucléaire double avec pores pour échanges sélectifs avec le cytoplasme",
      "Nucléole : siège de l'assemblage des sous-unités ribosomiques à partir d'ARN ribosomal",
      "Chromatine : support physique de l'information génétique (ADN)",
      "Rôle déterminant dans la réplication, la transcription et la régulation du cycle cellulaire"
    ],
    courseNote: "C'est le plus gros des organites cellulaires. Il détient le patrimoine génétique et contrôle la synthèse des protéines.",
    color: "#6366f1"
  },
  {
    id: "mitochondrie",
    name: "Mitochondrie",
    frenchSubtitle: "Centrale énergétique cellulaire (Production d'ATP)",
    structure: "Organite en forme de petit haricot délimité par une double membrane. La membrane interne forme des crêtes qui multiplient la surface réactionnelle.",
    function: "Respiration cellulaire aérobie et phosphorylation oxydative pour produire l'énergie vitale sous forme d'ATP (adénosine triphosphate).",
    details: [
      "Double membrane : membrane externe perméable et membrane interne très sélective formant les crêtes",
      "Matrice mitochondriale contenant les enzymes du cycle de Krebs",
      "Possède son propre génome : l'ADN mitochondrial (transmission maternelle exclusive)",
      "Auto-réplication semi-autonome selon les besoins énergétiques cellulaires"
    ],
    courseNote: "Petits haricots à double membrane interne plissée en crêtes. Fonction : respiration cellulaire + production d'énergie. NB : possèdent leur propre ADN mitochondrial.",
    color: "#ef4444"
  },
  {
    id: "re_granuleux",
    name: "Réticulum Endoplasmique Granuleux (REG / RER)",
    frenchSubtitle: "Sacs aplatis bordés de ribosomes (Synthèse des protéines)",
    structure: "Réseau de tubules et de saccules aplatis communiquant avec l'enveloppe nucléaire, couvert de ribosomes sur sa face cytosolique.",
    function: "Synthèse, repliement et maturation des protéines destinées à l'exportation membranaire ou lysosomale.",
    details: [
      "Rugueux du fait de la présence de milliers de ribosomes fixés",
      "Adjonction de chaînes glucidiques (début de la N-glycosylation)",
      "Émission de vésicules de transition à destination de l'appareil de Golgi"
    ],
    courseNote: "RE granuleux (rugueux) = ribosomes à sa surface, impliqué dans la synthèse des protéines.",
    color: "#8b5cf6"
  },
  {
    id: "re_lisse",
    name: "Réticulum Endoplasmique Lisse (REL)",
    frenchSubtitle: "Réseau tubulaire sans ribosomes (Synthèse des lipides)",
    structure: "Réseau tubulaire membrané dépourvu de ribosomes.",
    function: "Synthèse des lipides (phospholipides membranaires, stéroïdes), détoxification cellulaire et stockage crucial des ions Calcium (Ca2+).",
    details: [
      "Synthèse des lipides membranaires et hormones stéroïdiennes",
      "Réservoir intracellulaire majeur de Calcium (réticulum sarcoplasmique dans les myocytes)",
      "Détoxification des substances xénobiotiques et médicaments dans les hépatocytes"
    ],
    courseNote: "RE lisse = sans ribosomes (synthèse des lipides + stockage du calcium).",
    color: "#ec4899"
  },
  {
    id: "golgi",
    name: "Appareil de Golgi",
    frenchSubtitle: "Centre de tri, maturation et sécrétion cellulaire",
    structure: "Empilement de 4 à 8 saccules discoïdales incurvées (dictyosome) entourées de vésicules de transport.",
    function: "Activité sécrétoire : réception des protéines du REG, maturation chimique finale, tri, empaquetage et libération extracellulaire par exocytose.",
    details: [
      "Face cis (d'entrée) orientée vers le REG et face trans (de sortie) orientée vers la membrane plasmique",
      "O-glycosylation et sulfatation des protéines et glycoprotéines",
      "Production des lysosomes primaires et des vésicules sécrétoires"
    ],
    courseNote: "Saccules empilées les unes sur les autres. Fonction = activité sécrétoire, triage des protéines à sécréter, libération par exocytose.",
    color: "#f59e0b"
  },
  {
    id: "lysosome",
    name: "Lysosome",
    frenchSubtitle: "Vésicules de digestion intracellulaire",
    structure: "Vésicules sphériques délimitées par une membrane simple renfermant des hydrolases acides (pH 4.5 - 5.0).",
    function: "Digestion intracellulaire enzymatique de toutes les substances inutiles, débris cellulaires (autophagie) ou éléments phagocytés.",
    details: [
      "Contiennent plus de 40 types d'hydrolases acides protéolytiques",
      "Pompe à protons membranaire maintenant un milieu interne acide protecteur",
      "Élimination des organites sénescents et défense antimicrobienne"
    ],
    courseNote: "Vésicules contenant des enzymes hydrolases. Fonction = digestion intracellulaire de toutes les substances inutiles.",
    color: "#10b981"
  },
  {
    id: "ribosome",
    name: "Ribosome",
    frenchSubtitle: "Complexes ribonucléoprotéiques de traduction",
    structure: "Petites sphères sans membrane composées de 2 sous-unités (grande sous-unité 60S et petite 40S) associant ARN ribosomique et protéines.",
    function: "Synthèse des chaînes polypeptidiques (protéines) à partir des acides aminés libres du cytoplasme en suivant le code génétique de l'ARNm.",
    details: [
      "Peuvent être libres dans le hyaloplasme ou ancrés à la membrane du REG",
      "Lecture codon par codon du message transcrit depuis le noyau",
      "Usines universelles de fabrication de toutes les protéines du corps humain"
    ],
    courseNote: "Petites sphères composées de 2 parties, libres ou sur le RE. Fonction = synthèse des protéines selon les ordres du noyau.",
    color: "#06b6d4"
  },
  {
    id: "centrosome",
    name: "Centrosome & Centrioles",
    frenchSubtitle: "Centre organisateur des microtubules (Division cellulaire)",
    structure: "Constitué de 2 centrioles cylindriques disposés perpendiculairement l'un à l'autre (9 triplets de microtubules).",
    function: "Organisation du cytosquelette et formation du fuseau achromatique (mitotique) indispensable à la séparation des chromosomes pendant la mitose.",
    details: [
      "Duplication précise au cours de l'interphase (phase S et G2)",
      "Émission des fibres de l'aster et des microtubules kinétochoriens",
      "Moteur mécanique de la ségrégation des chromatides"
    ],
    courseNote: "Un centrosome = 2 centrioles perpendiculaires. Fonction = formation du fuseau achromatique lors de la division cellulaire.",
    color: "#3b82f6"
  },
  {
    id: "vacuole",
    name: "Vacuoles et Vésicules",
    frenchSubtitle: "Cavités sphériques de transport et réserve",
    structure: "Petites cavités sphériques mobiles délimitées par une bicouche phospholipidique.",
    function: "Stockage transitoire de substances de réserve, transport intracellulaire de molécules ou séquestration de déchets avant élimination.",
    details: [
      "Vésicules d'endocytose (phagosomes, pinosomes)",
      "Vésicules de sécrétion et de transport intra-golgien",
      "Maintien de l'équilibre volumique et osmotique"
    ],
    courseNote: "Petites cavités sphériques et mobiles. Fonctions = contiennent des substances de réserve ou des déchets à éliminer.",
    color: "#14b8a6"
  },
  {
    id: "cytoplasme",
    name: "Cytoplasme & Cytosquelette",
    frenchSubtitle: "Milieu intérieur cellulaire et armature dynamique",
    structure: "Ensemble du contenu délimité par la membrane plasmique : hyaloplasme (cytosol visqueux) + cytosquelette (microfilaments, microtubules, filaments intermédiaires) + organites.",
    function: "Siège des réactions métaboliques (glycolyse), maintien de la morphologie cellulaire, transports intracellulaires et ancrage des organites.",
    details: [
      "Hyaloplasme : liquide riche en eau, ions, acides aminés, glucose et enzymes solubles",
      "Cytosquelette : armature dynamique autorisant mobilité et résistance mécanique",
      "Courants cytoplasmiques facilitant la diffusion des solutés"
    ],
    courseNote: "Totalité du contenu délimité par la membrane : hyaloplasme (liquide visqueux) + cytosquelette (armature) + organites.",
    color: "#a855f7"
  }
];

export const MEMBRANE_TRANSPORTS = [
  {
    id: "passif",
    category: "Transports Passifs",
    energy: "Aucune dépense d'ATP (0 ATP)",
    gradient: "Selon le gradient de concentration (du milieu le plus concentré [+] vers le moins concentré [-])",
    mechanisms: [
      {
        name: "Diffusion Simple (Osmose)",
        desc: "Passage direct à travers la bicouche de petites molécules non polaires (O2, CO2, acides gras) ou d'eau (osmose).",
        speed: "Modérée",
        example: "Échanges gazeux alvéolo-capillaires pulmonaires"
      },
      {
        name: "Diffusion Facilitée",
        desc: "Passage de molécules chargées ou polaires grâce à une protéine transmembranaire : canal ionique (pore sélectif) ou perméase (transporteur à changement conformationnel).",
        speed: "Très rapide",
        example: "Entrée du glucose par les transporteurs GLUT ou canaux Na+/K+"
      }
    ],
    color: "#0ea5e9"
  },
  {
    id: "actif",
    category: "Transports Actifs",
    energy: "Nécessite de l'énergie métabolique sous forme d'ATP",
    gradient: "Contre le gradient de concentration (du milieu [-] vers le milieu [+])",
    mechanisms: [
      {
        name: "Pompe Ionique Na+/K+ ATPase",
        desc: "Expulsion de 3 ions Na+ hors de la cellule contre l'entrée de 2 ions K+ avec hydrolyse d'une molécule d'ATP.",
        speed: "Continue",
        example: "Maintien du potentiel de membrane de repos des neurones (-70 mV)"
      },
      {
        name: "Pompes à Protons H+ et Calcium Ca2+",
        desc: "Translocation active d'ions contre un fort gradient électrochimique (acidification gastrique, relaxation musculaire).",
        speed: "Régulée",
        example: "Pompe à protons gastrique (sécrétion de HCl par l'estomac)"
      }
    ],
    color: "#f97316"
  },
  {
    id: "vesiculaire",
    category: "Transports avec intervention de la membrane",
    energy: "Dépendance énergétique et réorganisation du cytosquelette",
    gradient: "Transport en masse de macromolécules et particules",
    mechanisms: [
      {
        name: "Endocytose (Phagocytose & Pinocytose)",
        desc: "Invagination de la membrane plasmique pour capturer des éléments extérieurs puis formation d'une vacuole interne. Phagocytose = particules solides (bactéries); Pinocytose = gouttelettes liquides.",
        speed: "Spécifique",
        example: "Macrophage éliminant un germe pathogène"
      },
      {
        name: "Exocytose",
        desc: "Fusion des vacuoles sécrétoires intracellulaires avec la membrane plasmique pour déverser leur contenu vers le milieu extracellulaire.",
        speed: "Déclenchée",
        example: "Libération d'hormones (insuline) ou de neurotransmetteurs"
      }
    ],
    color: "#10b981"
  }
];

export const CELL_CYCLE_PHASES = [
  {
    id: "interphase",
    period: "Interphase",
    duration: "Environ 90% du cycle cellulaire",
    role: "Période située entre deux mitoses successives. Préparation métabolique et réplication.",
    substages: [
      {
        name: "Phase G1 (Gap 1)",
        definition: "Croissance active de la cellule, synthèse protéique intense, préparation à la réplication de l'ADN.",
        state: "Les chromosomes possèdent 1 seule chromatide."
      },
      {
        name: "Phase S (Synthèse)",
        definition: "Réplication de l'acide désoxyribonucléique (ADN) et duplication des centrosomes.",
        state: "À la fin de la phase S, chaque chromosome possède 2 chromatides sœurs identiques unies par le centromère."
      },
      {
        name: "Phase G2 (Gap 2)",
        definition: "Dernière phase de croissance, synthèse des tubulines du fuseau, vérification de l'intégrité de l'ADN répliqué.",
        state: "La cellule est prête à entrer en mitose."
      }
    ]
  },
  {
    id: "mitose",
    period: "Mitose (Division Cellulaire)",
    duration: "Environ 10% du cycle cellulaire",
    role: "Division du noyau et du cytoplasme donnant naissance à deux cellules filles diploïdes rigoureusement identiques.",
    substages: [
      {
        name: "1. Prophase",
        definition: "Condensation de la chromatine en chromosomes distincts visibles. Disparition du nucléole. Fragmentation et dissolution de l'enveloppe nucléaire. Migration des deux centrosomes aux pôles opposés et formation du fuseau mitotique à partir des microtubules."
      },
      {
        name: "2. Métaphase",
        definition: "Alignement parfait des chromosomes au centre de la cellule le long de la plaque équatoriale, guidés par les fibres kinétochoriennes du fuseau mitotique."
      },
      {
        name: "3. Anaphase",
        definition: "Rupture des centromères et séparation brutale des chromatides sœurs. Chaque chromatide est tractée rapidement vers un pôle opposé de la cellule par raccourcissement des microtubules."
      },
      {
        name: "4. Télophase & Cytocinèse",
        definition: "Décondensation des chromatides en chromatine diffuse. Disparition du fuseau mitotique. Reconstitution des enveloppes nucléaires autour de chaque lot de chromosomes. Sillon de clivage pinçant la cellule en deux cellules filles indépendantes."
      }
    ]
  }
];

export const TISSUES: TissueInfo[] = [
  {
    id: "epithelial",
    name: "Tissu Épithélial (Épithélium)",
    description: "Recouvre la surface du corps et tapisse les cavités internes et conduits de l'organisme. Cellules jointives très serrées reposant sur une lame basale.",
    examples: ["Épiderme de la peau", "Muqueuse digestive et gastrique", "Épithélium respiratoire cilié", "Épithélium lingual (langue)", "Glandes exocrines et endocrines"],
    location: "Peau, tube digestif, voies respiratoires, cavités cœlomiques",
    role: "Protection mécanique et chimique, perméabilité sélective, absorption des nutriments, réabsorption et sécrétion glandulaire",
    color: "#f43f5e"
  },
  {
    id: "conjonctif",
    name: "Tissu Conjonctif et de Soutien",
    description: "Tissu de liaison le plus abondant du corps. Entoure, protège, isole et réunit les organes et structures anatomiques dans une matrice extracellulaire abondante.",
    examples: ["Tissu adipeux (graisse)", "Tendons et ligaments", "Cartilages (articulaire, trachéal, costal)", "Tissu osseux compact et spongieux", "Sang (tissu conjonctif liquide)"],
    location: "Sous tous les épithéliums, squelette, articulations, système vasculaire",
    role: "Liaison structurale, soutien mécanique, réserve métabolique, amortissement des chocs, transport nutritif (sang)",
    color: "#eab308"
  },
  {
    id: "musculaire",
    name: "Tissu Musculaire",
    description: "Tissu excitable spécialisé dans la contraction mécanique active grâce aux filaments intracellulaires d'actine et de myosine pour assurer le mouvement.",
    examples: [
      "Muscles locomoteurs squelettiques (biceps, quadriceps...)",
      "Myocarde cardiaque",
      "Parois des vaisseaux (artères, veines) et viscères (estomac, intestin, vessie)"
    ],
    subtypes: [
      {
        name: "Tissu musculaire squelettique",
        description: "Fibres striées, plurinucléées, à commande volontaire (système nerveux somatique). Assure la motricité et la posture."
      },
      {
        name: "Tissu musculaire cardiaque",
        description: "Strié, mononucléé, cellules ramifiées unies par des disques intercalaires. Contraction automatique involontaire et rythmique (myocarde)."
      },
      {
        name: "Tissu musculaire lisse",
        description: "Cellules fusiformes non striées, à commande involontaire végétative (viscères digestifs, voies urinaires et parois artérielles)."
      }
    ],
    location: "Membres, tronc, cœur, tube digestif, système vasculaire",
    role: "Mouvement du corps, maintien postural, propulsion du sang, péristaltisme digestif, thermogenèse (frissons)",
    color: "#ef4444"
  },
  {
    id: "nerveux",
    name: "Tissu Nerveux",
    description: "Réseau complexe de communication et de régulation coordonnant l'ensemble des activités corporelles. Composé de neurones excitables et de cellules gliales nourricières.",
    examples: ["Encéphale (cerveau, cervelet, tronc cérébral)", "Moelle épinière", "Nerfs crâniens et rachidiens / spinaux", "Ganglions nerveux et récepteurs sensoriels"],
    location: "Système nerveux central et périphérique",
    role: "Recueil sensoriel, traitement intégratif des informations, mémoire, genèse et transmission des influx nerveux moteurs et végétatifs",
    color: "#06b6d4"
  }
];

export const STOMACH_ORGAN_EXAMPLE = {
  title: "Exemple d'Organe : L'Estomac",
  definition: "Un organe est un ensemble de tissus différents associés en vue d'assurer une même fonction.",
  description: "L'estomac démontre parfaitement cette synergie : pour réaliser la digestion mécanique et chimique du bol alimentaire, il imbrique intimement les 4 tissus fondamentaux :",
  layers: [
    {
      tissue: "Tissu Épithélial (Muqueuse gastrique)",
      role: "Tapisse l'intérieur de la lumière stomacale. Sécrète le suc gastrique (acide chlorhydrique HCl et pepsine) et un mucus protecteur dense évitant l'autodigestion de la paroi."
    },
    {
      tissue: "Tissu Conjonctif (Sous-muqueuse)",
      role: "Tissu conjonctif lâche richement vascularisé (artérioles, veinules, capillaires) et innervé (plexus de Meissner) apportant nutriments et oxygène à la paroi."
    },
    {
      tissue: "Tissu Musculaire Lisse (Musculeuse)",
      role: "Composé de 3 couches de fibres musculaires lisses orientées différemment (longitudinale, circulaire, oblique) assurant le brassage vigoureux et la vidange vers le duodénum."
    },
    {
      tissue: "Tissu Nerveux (Plexus entérique d'Auerbach)",
      role: "Réseau nerveux intrinsèque coordonnant la contraction séquentielle des couches musculaires et modulant les sécrétions acides selon la présence d'aliments."
    }
  ]
};

export const HUMAN_SYSTEMS: SystemInfo[] = [
  {
    id: "digestif",
    name: "Système Digestif",
    iconName: "Utensils",
    category: "Nutrition & Métabolisme",
    organs: ["Cavité buccale", "Glandes salivaires", "Pharynx", "Œsophage", "Estomac", "Foie & Vésicule biliaire", "Pancréas exocrine", "Intestin grêle", "Gros intestin", "Rectum"],
    mainFunction: "Ingestion, digestion mécanique et chimique des aliments, absorption des nutriments et élimination des résidus non digérés.",
    physiologicalRole: "Convertit les macromolécules ingérées en nutriments simples (acides aminés, glucose, acides gras) absorbables par le sang à travers la villosité intestinale.",
    clinicalRelevance: "Ulcères gastriques, malabsorption, cirrhose hépatique, colites, lithiase biliaire.",
    interdependence: "Fournit au système cardiovasculaire les substrats énergétiques que le sang distribue à toutes les cellules vivantes.",
    color: "#f59e0b"
  },
  {
    id: "respiratoire",
    name: "Système Respiratoire",
    iconName: "Wind",
    category: "Ventilation & Gaz sanguins",
    organs: ["Fosses nasales & Sinus", "Pharynx", "Larynx & Cordes vocales", "Trachée cartilagineuse", "Bronches souches et lobaires", "Poumons & Alvéoles", "Diaphragme & Muscles intercostaux"],
    mainFunction: "Ventilation pulmonaire et hématose : approvisionnement en oxygène (O2) et rejet du dioxyde de carbone (CO2).",
    physiologicalRole: "Diffusion passive alvéolo-capillaire selon les gradients de pression partielle. Participe à la régulation fine du pH sanguin par élimination du CO2.",
    clinicalRelevance: "Insuffisance respiratoire, pneumonies, bronchopneumopathie chronique obstructive (BPCO), asthme aigu.",
    interdependence: "Collabore étroitement avec le système cardio-vasculaire pour oxygéner l'hémoglobine et avec le système urinaire pour l'équilibre acido-basique.",
    color: "#06b6d4"
  },
  {
    id: "cardiovasculaire",
    name: "Système Cardio-Vasculaire",
    iconName: "HeartPulse",
    category: "Circulation & Distribution",
    organs: ["Cœur (Myocarde, oreillettes, ventricules)", "Artères à haute pression", "Capillaires d'échanges", "Veines et valvules", "Sang hématies/leucocytes/plaquettes"],
    mainFunction: "Propulsion et acheminement continu du sang oxygéné et nutritif vers tous les tissus et retour du sang veineux.",
    physiologicalRole: "Génère le gradient de pression hydrostatique (pression artérielle) et assure les échanges au niveau de la microcirculation tissulaire.",
    clinicalRelevance: "Infarctus du myocarde, hypertension artérielle, insuffisance cardiaque congestive, thrombose veineuse profonde.",
    interdependence: "Véhicule central reliant tous les systèmes : transporte les hormones endocrines, les nutriments digestifs, l'O2 respiratoire et les déchets vers les reins.",
    color: "#ef4444"
  },
  {
    id: "urinaire",
    name: "Système Urinaire",
    iconName: "Droplet",
    category: "Excrétion & Homéostasie liquidienne",
    organs: ["Reins (cortex, médullaire, néphrons)", "Uretères", "Vessie urinaire", "Urètre"],
    mainFunction: "Filtration du sang, épuration des déchets métaboliques azotés (urée, créatinine) et production de l'urine.",
    physiologicalRole: "Régulation du volume plasmatique (volémie), régulation de la tension artérielle (axe rénine-angiotensine), osmolarité et équilibre ionique (Na+, K+, HCO3-).",
    clinicalRelevance: "Insuffisance rénale aiguë et chronique, lithiases urinaires, pyélonéphrite, désordres électrolytiques.",
    interdependence: "Élimine les déchets métaboliques en synergie avec le système respiratoire et préserve l'équilibre volémique cardio-vasculaire.",
    color: "#3b82f6"
  },
  {
    id: "locomoteur",
    name: "Système Locomoteur (Squelette & Muscles)",
    iconName: "Activity",
    category: "Posture & Motricité",
    organs: ["206 os squelettiques", "Articulations synoviales", "Cartilages articulaires", "Tendons & Ligaments", "Plus de 600 muscles squelettiques striés"],
    mainFunction: "Soutien mécanique de la charpente corporelle, protection des organes vitaux nobles (boîte crânienne, cage thoracique) et motricité active.",
    physiologicalRole: "Bras de leviers osseux actionnés par la contraction musculaire. Réserve majeure de sels minéraux (99% du calcium corporel) et hématopoïèse médullaire osseuse.",
    clinicalRelevance: "Fractures, arthrose dégénérative, ostéoporose, déchirures ligamentaires et musculaires.",
    interdependence: "Sous la commande directe du système nerveux moteur et approvisionné par les réseaux cardiovasculaire et digestif.",
    color: "#a855f7"
  },
  {
    id: "nerveux",
    name: "Système Nerveux (SNC & SNP)",
    iconName: "Cpu",
    category: "Contrôle rapide & Intégration",
    organs: ["Système Nerveux Central : Cerveau, Cervelet, Tronc cérébral, Moelle épinière", "Système Nerveux Périphérique : 12 paires de nerfs crâniens, 31 paires de nerfs spinaux", "Organes sensoriels : yeux, oreilles, nez, langue, peau"],
    mainFunction: "Régulation rapide de l'organisme : détection des stimuli internes et externes, traitement cognitif et déclenchement de réponses motrices ou sécrétoires.",
    physiologicalRole: "Propagation d'ondes de dépolarisation membranaire (potentiels d'action) et transmission synaptique neurochimique.",
    clinicalRelevance: "Accidents vasculaires cérébraux (AVC), traumatismes crâniens, sclérose en plaques, épilepsie, comas.",
    interdependence: "Pilote supérieur coordonnant instantanément la respiration, le rythme cardiaque, le tonus musculaire et le système endocrinien.",
    color: "#14b8a6"
  },
  {
    id: "endocrinien",
    name: "Système Endocrinien",
    iconName: "Sparkles",
    category: "Régulation lente & Métabolique",
    organs: ["Hypothalamus", "Hypophyse (glande pituitaire)", "Glande pinéale (épiphyse)", "Glande thyroïde", "Thymus", "Glandes surrénales", "Pancréas endocrine (îlots de Langerhans)", "Gonades (ovaires, testicules)"],
    mainFunction: "Sécrétion d'hormones déversées directement dans le sang pour moduler l'activité à distance d'organes cibles spécifiques.",
    physiologicalRole: "Régulation homéostasique à moyen et long terme : croissance, métabolisme glucidique (insuline/glucagon), équilibre hydrominéral, stress et reproduction.",
    clinicalRelevance: "Diabète de type 1 et 2, hypothyroïdie, hyperthyroïdie, syndrome de Cushing, maladie d'Addison.",
    interdependence: "Complément direct du système nerveux : là où le système nerveux agit en millisecondes, le système endocrinien agit sur des heures ou des semaines.",
    color: "#e11d48"
  },
  {
    id: "reproducteur",
    name: "Système Reproducteur",
    iconName: "Heart",
    category: "Pérennité de l'espèce & Gamétogenèse",
    organs: [
      "Homme : Testicules, épididyme, canaux déférents, vésicules séminales, prostate, urètre, pénis, scrotum",
      "Femme : Ovaires, trompes de Fallope, utérus, col utérin, vagin, vulve, glandes mammaires"
    ],
    mainFunction: "Production des gamètes haploïdes (spermatozoïdes et ovocytes), fécondation, gestation fœtale et sécrétion des hormones sexuelles.",
    physiologicalRole: "Méiose germinale, maintien des caractères sexuels secondaires et régulation des cycles menstruels et reproducteurs.",
    clinicalRelevance: "Infertilité, adénome prostatique, endométriose, grossesses extra-utérines, kystes ovariens.",
    interdependence: "Étroitement commandé par l'axe hypothalamo-hypophysaire endocrinien (LH, FSH).",
    color: "#8b5cf6"
  },
  {
    id: "tegumentaire",
    name: "Système Tégumentaire (Peau & Phanères)",
    iconName: "Shield",
    category: "Protection & Barrière corporelle",
    organs: ["Épiderme stratifié kératinisé", "Derme riche en collagène, élastine et capillaires", "Hypoderme riche en tissu adipeux", "Poils et cheveux", "Glandes sudoripares et sébacées", "Ongles", "Récepteurs cutanés tactiles et thermiques"],
    mainFunction: "Barrière protectrice physique, chimique et biologique contre l'environnement extérieur, les agressions mécaniques et les agents infectieux.",
    physiologicalRole: "Thermorégulation active (vasodilatation cutanée et sudation), perception tactile et synthèse de la vitamine D sous l'action des UV solaires.",
    clinicalRelevance: "Brûlures graves, mélanomes, escarres, dermatites, plaies chirurgicales.",
    interdependence: "Protège tous les organes sous-jacents contre la déshydratation et communique en continu avec le système nerveux sensoriel.",
    color: "#d97706"
  },
  {
    id: "lymphatique",
    name: "Système Lymphatique & Immunitaire",
    iconName: "ShieldCheck",
    category: "Défense immunitaire & Drainage liquidien",
    organs: ["Vaisseaux et capillaires lymphatiques", "Ganglions lymphatiques cervicaux, axillaires et inguinaux", "Rate", "Thymus", "Amygdales palatines", "Plexus lymphatique mammaire", "Canal thoracique"],
    mainFunction: "Drainage de l'excédent de liquide interstitiel vers la circulation veineuse et surveillance immunitaire contre les agents pathogènes.",
    physiologicalRole: "Transport de la lymphe, maturation des lymphocytes B et T, phagocytose des corps étrangers et filtration des antigènes circulants.",
    clinicalRelevance: "Lymphœdème, lymphomes, adénopathies infectieuses, splénomégalie, déficits immunitaires.",
    interdependence: "Retourne les fluides au système cardiovasculaire et protège tous les systèmes contre les infections microbiennes.",
    color: "#10b981"
  }
];

export const CONCLUSION_INTEGRATION = {
  quote: "Aucun des systèmes ne travaille de façon totalement indépendante ; ils collaborent tous au bien-être de l'organisme entier.",
  pillars: [
    {
      title: "Apport Energétique & O2",
      description: "Le système digestif et le système respiratoire communiquent avec l'environnement extérieur et apportent respectivement les nutriments et le dioxygène au sang qui les distribue ensuite à chacune des 100 000 milliards de cellules du corps.",
      systems: ["Digestif", "Respiratoire", "Cardio-vasculaire"]
    },
    {
      title: "Épuration & Déchets Métaboliques",
      description: "Le système urinaire (reins) et le système respiratoire (poumons) éliminent en permanence les déchets métaboliques de l'organisme (urée, créatinine, CO2 acide, excès d'ions) pour préserver la constance du milieu intérieur.",
      systems: ["Urinaire", "Respiratoire", "Cardio-vasculaire"]
    },
    {
      title: "Coordination & Homéostasie",
      description: "Le système nerveux assure la réponse réflexe ultrarapide et le système endocrinien régule les processus lents et durables, permettant à l'organisme de s'adapter harmonieusement aux variations du milieu.",
      systems: ["Nerveux", "Endocrinien", "Locomoteur"]
    }
  ]
};

export const QUIZ_QUESTIONS = [
  {
    id: 1,
    question: "Quelle est la définition exacte de la PHYSIOLOGIE selon le cours ?",
    options: [
      "L'étude de la forme et de la structure du corps et de ses parties",
      "L'étude du fonctionnement du corps et de ses parties, c'est-à-dire de la façon dont celles-ci jouent leurs rôles",
      "L'étude exclusive des maladies affectant les tissus musculaires",
      "L'analyse microscopique de la membrane plasmique uniquement"
    ],
    correctAnswer: 1,
    explanation: "Selon la diapositive 5 : La physiologie est l'étude du fonctionnement du corps et de ses parties, c'est-à-dire de la façon dont celles-ci jouent leurs rôles. L'anatomie étudie quant à elle la forme et la structure."
  },
  {
    id: 2,
    question: "Pourquoi l'être humain est-il qualifié d'organisme 'Eucaryote' ?",
    options: [
      "Parce qu'il ne contient qu'une seule cellule bactérienne",
      "Parce que ses cellules ne possèdent pas de membrane plasmique",
      "Parce que ses cellules possèdent un noyau bien défini et des organites compartimentés par des membranes",
      "Parce qu'il synthétise ses protéines sans ribosomes"
    ],
    correctAnswer: 2,
    explanation: "Diapositive 8 : L'être humain comporte environ 100 000 milliards de cellules eucaryotes, qui possèdent un noyau bien défini et des organites compartimentés par des membranes, contrairement aux procaryotes (comme les bactéries)."
  },
  {
    id: 3,
    question: "Quelle est la particularité génétique remarquable des mitochondries ?",
    options: [
      "Elles ne contiennent aucune enzyme respiratoire",
      "Elles possèdent leur propre matériel génétique : l'ADN mitochondrial",
      "Leur membrane interne est totalement lisse sans aucun repli",
      "Elles fabriquent la totalité des lipides cellulaires"
    ],
    correctAnswer: 1,
    explanation: "Diapositive 13 : Les mitochondries possèdent une double membrane avec crêtes internes et possèdent leur propre matériel génétique : l'ADN mitochondrial."
  },
  {
    id: 4,
    question: "Quelle est la différence fondamentale entre le RE Granuleux et le RE Lisse ?",
    options: [
      "Le RE granuleux possède des ribosomes à sa surface (synthèse des protéines) tandis que le RE lisse n'en a pas (synthèse des lipides et stockage du calcium)",
      "Le RE granuleux se situe dans le noyau et le RE lisse dans la mitochondrie",
      "Le RE granuleux produit l'ATP et le RE lisse produit l'ARN",
      "Le RE lisse est responsable de la division cellulaire par le fuseau achromatique"
    ],
    correctAnswer: 0,
    explanation: "Diapositive 14 : RE granuleux (rugueux) = ribosomes à sa surface (synthèse de protéines) ; RE lisse = sans ribosomes (synthèse des lipides + stockage du calcium)."
  },
  {
    id: 5,
    question: "Quel organite cellulaire contient des enzymes hydrolases pour la digestion intracellulaire des substances inutiles ?",
    options: [
      "L'appareil de Golgi",
      "Le ribosome",
      "Le lysosome",
      "Le centrosome"
    ],
    correctAnswer: 2,
    explanation: "Diapositive 16 : Les lysosomes sont des vésicules contenant des enzymes appelées hydrolases, ayant pour fonction la digestion intracellulaire de toutes les substances inutiles."
  },
  {
    id: 6,
    question: "De quoi est composé un centrosome et quel est son rôle essentiel ?",
    options: [
      "De deux mitochondries fusionnées qui produisent le calcium",
      "De deux centrioles perpendiculaires qui forment le fuseau achromatique lors de la division cellulaire",
      "De sacs aplatis golgiens responsables de l'exocytose",
      "D'ARN et de protéines assurant la traduction cytoplasmique"
    ],
    correctAnswer: 1,
    explanation: "Diapositive 17 : Un centrosome est formé de 2 centrioles perpendiculaires. Sa fonction est la formation du fuseau achromatique lors de la division cellulaire."
  },
  {
    id: 7,
    question: "Dans le transport actif membranaire, quelle affirmation est vraie ?",
    options: [
      "Il s'effectue sans aucune dépense d'énergie le long du gradient",
      "Il nécessite de l'énergie sous forme d'ATP et s'effectue contre le gradient de concentration",
      "Il ne concerne que le passage de l'eau par osmose",
      "Il ne fait intervenir aucune protéine transmembranaire"
    ],
    correctAnswer: 1,
    explanation: "Diapositive 11 : Le transport actif nécessite de l'énergie sous forme d'ATP et s'effectue contre le gradient de concentration grâce à une protéine pompe (ex: pompe à protons, Na+, Ca++)."
  },
  {
    id: 8,
    question: "À quelle étape de la mitose les chromatides sœurs se séparent-elles pour aller vers un pôle opposé de la cellule ?",
    options: [
      "La prophase",
      "La métaphase",
      "L'anaphase",
      "La télophase"
    ],
    correctAnswer: 2,
    explanation: "Diapositive 21 : L'anaphase correspond à la séparation des chromatides sœurs, chacune se déplaçant vers un pôle opposé de la cellule grâce au raccourcissement des fibres du fuseau."
  },
  {
    id: 9,
    question: "Quels sont les 4 grands groupes de tissus présents chez l'Homme ?",
    options: [
      "Tissu osseux, tissu cartilagineux, tissu sanguin, tissu adipeux",
      "Tissu épithélial, tissu conjonctif, tissu musculaire, tissu nerveux",
      "Tissu dermique, tissu épidermique, tissu hypodermique, tissu muqueux",
      "Tissu stomacal, tissu cardiaque, tissu pulmonaire, tissu rénal"
    ],
    correctAnswer: 1,
    explanation: "Diapositives 24 à 28 : Il existe 4 groupes de tissus chez l'homme : épithélial, conjonctif, musculaire, et nerveux."
  },
  {
    id: 10,
    question: "Quels sont les tissus retrouvés dans la paroi de l'estomac illustrant la définition d'un organe ?",
    options: [
      "Uniquement du tissu musculaire squelettique strié",
      "Du tissu épithélial, du tissu musculaire lisse, du tissu conjonctif et du tissu nerveux",
      "Seulement du cartilage et de l'os",
      "Du tissu conjonctif sans aucun revêtement épithélial"
    ],
    correctAnswer: 1,
    explanation: "Diapositive 30 : Dans l'estomac, qui constitue un organe, on trouve du tissu épithélial (muqueuse), du tissu musculaire lisse, du tissu conjonctif et du tissu nerveux (plexus)."
  },
  {
    id: 11,
    question: "Quelle est la conclusion fondamentale du cours concernant les relations entre les différents systèmes ?",
    options: [
      "Chaque système fonctionne en autonomie absolue sans communiquer avec les autres",
      "Aucun des systèmes ne travaille de façon totalement indépendante ; ils collaborent tous au bien-être de l'organisme entier",
      "Seul le système nerveux est nécessaire à la survie de l'organisme",
      "Le système respiratoire n'a aucun lien avec le système cardio-vasculaire"
    ],
    correctAnswer: 1,
    explanation: "Diapositive 43 : Conclusion : 'Aucun des systèmes ne travaille de façon totalement indépendante ; ils collaborent tous au bien-être de l'organisme entier'."
  }
];

export const GLOSSARY_TERMS = [
  { term: "Anatomie", def: "Discipline biologique et médicale étudiant la forme, la structure et la topographie des parties du corps et leurs relations spatiales réciproques." },
  { term: "Physiologie", def: "Discipline étudiant le fonctionnement dynamique des organes et tissus, et les mécanismes de régulation qui maintiennent la vie." },
  { term: "Homéostasie", def: "Capacité de l'organisme à maintenir constants ses paramètres internes (température, glycémie, pH, volémie) malgré les fluctuations extérieures." },
  { term: "Eucaryote", def: "Organisme dont les cellules possèdent un véritable noyau entouré d'une membrane protectrice et des organites compartimentés." },
  { term: "Diffusion simple", def: "Transport passif de molécules à travers la bicouche phospholipidique sans protéine transporteuse ni dépense d'ATP, dans le sens du gradient." },
  { term: "Diffusion facilitée", def: "Passage passif de solutés le long de leur gradient de concentration via des canaux ioniques ou des perméases protéiques." },
  { term: "Transport actif", def: "Déplacement de solutés contre leur gradient électrochimique nécessitant l'hydrolyse d'ATP par une protéine pompe (ex: pompe Na+/K+)." },
  { term: "Endocytose", def: "Mécanisme par lequel la cellule capture des macromolécules par invagination de sa membrane plasmique pour former des vésicules." },
  { term: "Phagocytose", def: "Type d'endocytose impliquant l'ingestion de grosses particules solides (ex: débris, bactéries par les neutrophiles et macrophages)." },
  { term: "Exocytose", def: "Processus de fusion de vésicules intracellulaires avec la membrane plasmique pour libérer des molécules dans le milieu extracellulaire." },
  { term: "Cristae (Crêtes mitochondriales)", def: "Replis plissés de la membrane interne de la mitochondrie où sont localisées les chaînes respiratoires et l'ATP synthase." },
  { term: "Fuseau achromatique (mitotique)", def: "Ensemble de microtubules rayonnant à partir des centrosomes permettant la ségrégation équitable des chromosomes pendant la mitose." },
  { term: "Chromatide sœur", def: "Une des deux copies identiques d'un chromosome répliqué, réunies au niveau du centromère avant leur séparation en anaphase." },
  { term: "Tissu épithélial", def: "Tissu constitué de cellules étroitement juxtaposées qui tapisse les surfaces externes et cavités corporelles ou forme des glandes." },
  { term: "Tissu conjonctif", def: "Tissu de soutien et de remplissage caractérisé par des cellules dispersées au sein d'une matrice extracellulaire riche en fibres." },
  { term: "Myocyte", def: "Cellule musculaire contractile spécialisée (striée squelettique, striée cardiaque ou lisse viscérale)." },
  { term: "Système HLA", def: "Antigènes des leucocytes humains (Human Leukocyte Antigen) portés par la membrane plasmique permettant la reconnaissance du soi immunologique." },
  { term: "Néphron", def: "Unité fonctionnelle microscopique du rein assurant la filtration glomérulaire, la réabsorption tubulaire et la formation de l'urine." }
];
