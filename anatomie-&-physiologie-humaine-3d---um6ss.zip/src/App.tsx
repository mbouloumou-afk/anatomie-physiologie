/**
 * Plateforme 3D d'Apprentissage : Anatomie & Physiologie Humaine
 * Module S1 - Filière SI/RR (IP - IAR - IBO - KINE)
 * Université Mohammed VI des Sciences et de la Santé (UM6SS) - Marrakech
 * Enseignant : Dr BADRAOUI Marouane (2026-2027)
 */

import React, { useState } from 'react';
import {
  COURSE_METADATA,
  DEFINITIONS,
  HIERARCHY_LEVELS,
  CONCLUSION_INTEGRATION,
  IMAGES,
} from './data/courseData';
import { Navbar } from './components/Navbar';
import { Body3DScene } from './components/canvas/Body3DScene';
import { Cell3DScene } from './components/canvas/Cell3DScene';
import { Transport3DScene } from './components/canvas/Transport3DScene';
import { Mitosis3DScene } from './components/canvas/Mitosis3DScene';
import { TissueOrgan3DScene } from './components/canvas/TissueOrgan3DScene';
import { SystemsExplorer } from './components/SystemsExplorer';
import { RealPhotosGallery } from './components/RealPhotosGallery';
import { QuizModule } from './components/QuizModule';
import { GlossaryModal } from './components/GlossaryModal';
import { CourseSummaryModal } from './components/CourseSummaryModal';
import {
  Activity,
  Layers,
  Sparkles,
  ArrowRight,
  BookOpen,
  GraduationCap,
  ChevronDown,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';

export default function App() {
  const [isGlossaryOpen, setIsGlossaryOpen] = useState(false);
  const [isSummaryOpen, setIsSummaryOpen] = useState(false);
  const [selectedHierarchyLevel, setSelectedHierarchyLevel] = useState(1);
  const [focusedSystemId, setFocusedSystemId] = useState<string | null>(null);

  const handleSelectOrganFrom3D = (organId: string) => {
    setFocusedSystemId(organId);
    // Smooth scroll down to systems section
    const el = document.getElementById('systemes');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased selection:bg-teal-500/30 selection:text-teal-200">
      {/* 1. Global Navigation Bar */}
      <Navbar
        onOpenGlossary={() => setIsGlossaryOpen(true)}
        onOpenSummary={() => setIsSummaryOpen(true)}
      />

      {/* Main Page Body Container */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-20">
        {/* Academic Course Badge & Metadata Header */}
        <section className="space-y-4">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
            <span className="text-teal-400 font-semibold">{COURSE_METADATA.university}</span>
            <span aria-hidden="true">·</span>
            <span>{COURSE_METADATA.faculty}</span>
            <span aria-hidden="true">·</span>
            <span>Filière {COURSE_METADATA.filiere}</span>
            <span aria-hidden="true">·</span>
            <span>{COURSE_METADATA.semester}</span>
            <span aria-hidden="true">·</span>
            <span>Année {COURSE_METADATA.academicYear}</span>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
            <div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight text-balance">
                Anatomie & Physiologie Humaine 3D
              </h1>
              <p className="text-sm sm:text-base text-slate-300 mt-2 max-w-3xl leading-relaxed">
                Module fondamental enseigné par le <strong className="text-white">{COURSE_METADATA.professor}</strong>.
                Explorez l'organisation intégrale du corps humain, de l'infiniment petit cellulaire aux 10 grands appareils physiologiques grâce à des animations 3D temps réel et des supports anatomiques réels.
              </p>
            </div>

            {/* Quick unboxed figures */}
            <div className="flex items-center gap-5 text-xs text-slate-400 border-l border-slate-800 pl-5 shrink-0">
              <div>
                <span className="text-lg font-bold text-teal-400 block tabular-nums">100 000 Md</span>
                <span>Cellules eucaryotes</span>
              </div>
              <div className="w-px h-8 bg-slate-800" />
              <div>
                <span className="text-lg font-bold text-cyan-400 block tabular-nums">4 Groupes</span>
                <span>Tissus fondamentaux</span>
              </div>
              <div className="w-px h-8 bg-slate-800" />
              <div>
                <span className="text-lg font-bold text-rose-400 block tabular-nums">10 Systèmes</span>
                <span>Interdépendants</span>
              </div>
            </div>
          </div>
        </section>

        {/* 2. Atlas 3D Principal & Body Viewer */}
        <section id="atlas3d" className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs uppercase font-bold tracking-wider text-teal-400">
                Visualiseur Spatial 3D Temps Réel
              </span>
              <h2 className="text-2xl font-bold text-white mt-0.5">
                Modèle Anatomique Interactif du Corps Humain
              </h2>
            </div>
            <a
              href="#organisation"
              className="hidden sm:flex items-center gap-1.5 text-xs text-teal-400 hover:text-teal-300 font-medium"
            >
              <span>Descendre au cours</span>
              <ChevronDown className="w-4 h-4" />
            </a>
          </div>

          {/* 3D Scene Component */}
          <Body3DScene onSelectOrgan={handleSelectOrganFrom3D} selectedOrganId={focusedSystemId} />

          {/* Side by side real medical visual and objectives */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 bg-slate-900/60 border border-slate-800 rounded-2xl p-6 items-center">
            <div className="md:col-span-4 relative overflow-hidden rounded-xl border border-slate-700/80 group">
              <img
                src={IMAGES.hero}
                alt="Visualisation anatomique réelle des systèmes du corps humain"
                className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex items-end p-3">
                <span className="text-[11px] text-slate-200 font-semibold">
                  Atlas Réel des Réseaux d'Organes (UM6SS)
                </span>
              </div>
            </div>

            <div className="md:col-span-8 space-y-3">
              <span className="text-xs uppercase font-bold tracking-wider text-teal-400">
                Objectifs Pédagogiques du Module (Slide 3)
              </span>
              <h3 className="text-lg font-bold text-white">
                Tout travail sur le corps humain suppose une connaissance minimale de son organisation générale.
              </h3>
              <ul className="space-y-2 text-xs text-slate-300">
                {COURSE_METADATA.objectives.map((obj, i) => (
                  <li key={i} className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
                    <span>{obj}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* Real Photos & Electron Microscopy Gallery Section */}
        <section id="photos-reelles" className="space-y-6 pt-4 border-t border-slate-900">
          <RealPhotosGallery />
        </section>

        {/* 3. Chapitre 1 : Définitions et Hiérarchie du Corps Humain */}
        <section id="organisation" className="space-y-6 pt-4 border-t border-slate-900">
          <div>
            <span className="text-xs uppercase font-bold tracking-wider text-teal-400">
              Chapitre 1 · Slides 4 à 6
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-white mt-1">
              Définitions & Organisation du Corps Humain
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Distinction fondamentale entre forme morphologique et rôle physiologique, et les 5 niveaux d'intégration biologique.
            </p>
          </div>

          {/* Definitions Cards: Anatomie vs Physiologie */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono text-teal-400">{DEFINITIONS.anatomie.etymology}</span>
                  <span className="text-[10px] uppercase font-bold text-slate-500">Morphologie</span>
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">{DEFINITIONS.anatomie.title}</h3>
                <p className="text-xs text-teal-200/90 leading-relaxed font-medium bg-teal-950/30 p-3.5 rounded-xl border border-teal-800/30">
                  « {DEFINITIONS.anatomie.definition} »
                </p>
                <p className="text-xs text-slate-400 mt-3 leading-relaxed">
                  {DEFINITIONS.anatomie.focus}
                </p>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono text-cyan-400">{DEFINITIONS.physiologie.etymology}</span>
                  <span className="text-[10px] uppercase font-bold text-slate-500">Fonctionnement</span>
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">{DEFINITIONS.physiologie.title}</h3>
                <p className="text-xs text-cyan-200/90 leading-relaxed font-medium bg-cyan-950/30 p-3.5 rounded-xl border border-cyan-800/30">
                  « {DEFINITIONS.physiologie.definition} »
                </p>
                <p className="text-xs text-slate-400 mt-3 leading-relaxed">
                  {DEFINITIONS.physiologie.focus}
                </p>
              </div>
            </div>
          </div>

          {/* Interactive Living Hierarchy Levels (Cellule -> Tissus -> Organes -> Systèmes -> Organisme) */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                Les 5 Niveaux d'Organisation Hiérarchique (Slides 6 & 42)
              </h4>
              <span className="text-xs text-slate-400">
                Cliquez sur un niveau pour examiner son échelle et sa description
              </span>
            </div>

            {/* Stepper Buttons */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {HIERARCHY_LEVELS.map((lvl) => (
                <button
                  key={lvl.id}
                  onClick={() => setSelectedHierarchyLevel(lvl.level)}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    selectedHierarchyLevel === lvl.level
                      ? 'bg-teal-500 text-slate-950 font-bold border-teal-400 shadow-md'
                      : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:bg-slate-900 hover:text-white'
                  }`}
                >
                  <div className={`text-[10px] uppercase font-bold ${selectedHierarchyLevel === lvl.level ? 'text-slate-900' : 'text-slate-500'}`}>
                    Niveau {lvl.level}
                  </div>
                  <div className="text-xs font-bold mt-0.5">{lvl.title}</div>
                  <div className={`text-[10px] mt-1 ${selectedHierarchyLevel === lvl.level ? 'text-slate-900' : 'text-slate-400'}`}>
                    Échelle : {lvl.scale}
                  </div>
                </button>
              ))}
            </div>

            {/* Selected Level Description Deck */}
            {(() => {
              const currentLvl = HIERARCHY_LEVELS[selectedHierarchyLevel - 1];
              return (
                <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 animate-in fade-in duration-200">
                  <div className="space-y-1.5 text-xs">
                    <span className="text-[10px] uppercase tracking-wider font-bold text-teal-400">
                      Niveau {currentLvl.level} · {currentLvl.count}
                    </span>
                    <h5 className="text-base font-bold text-white">{currentLvl.definition}</h5>
                    <p className="text-slate-400 leading-relaxed max-w-2xl">{currentLvl.description}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-[10px] text-slate-500 block uppercase font-mono">Dimension</span>
                    <span className="text-sm font-bold text-teal-400 font-mono">{currentLvl.scale}</span>
                  </div>
                </div>
              );
            })()}
          </div>
        </section>

        {/* 4. Chapitre 2 : La Cellule Eucaryote Humaine (Ultrastructure 3D) */}
        <section id="cellule" className="space-y-6 pt-4 border-t border-slate-900">
          <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-4">
            <div>
              <span className="text-xs uppercase font-bold tracking-wider text-cyan-400">
                Chapitre 2 · Slides 7 à 18
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold text-white mt-1">
                La Cellule Eucaryote & ses Organites
              </h2>
              <p className="text-xs text-slate-400 mt-1 max-w-2xl">
                Unité fondamentale, structurale et fonctionnelle des organismes vivants (100 000 milliards de cellules).
                Explorez le noyau, les mitochondries à crêtes, le réticulum endoplasmique, l'appareil de Golgi et les lysosomes en 3D.
              </p>
            </div>

            <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl flex items-center gap-3 shrink-0">
              <img
                src={IMAGES.cell}
                alt="Ultrastructure 3D de la cellule eucaryote"
                className="w-12 h-12 rounded-lg object-cover border border-slate-700"
                referrerPolicy="no-referrer"
              />
              <div className="text-xs">
                <span className="font-bold text-white block">Organisme Eucaryote</span>
                <span className="text-slate-400 text-[11px]">Noyau bien défini + organites compartimentés</span>
              </div>
            </div>
          </div>

          {/* Interactive 3D Cutaway Cell with Organelles */}
          <Cell3DScene />
        </section>

        {/* 5. Transports Membranaires 3D */}
        <section id="transports" className="space-y-6 pt-4 border-t border-slate-900">
          <Transport3DScene />
        </section>

        {/* 6. Division Cellulaire, Mitose & Différenciation 3D */}
        <section id="mitose" className="space-y-6 pt-4 border-t border-slate-900">
          <Mitosis3DScene />
        </section>

        {/* 7. Les 4 Tissus Fondamentaux & L'Organe (Estomac 3D) */}
        <section id="tissus" className="space-y-6 pt-4 border-t border-slate-900">
          <TissueOrgan3DScene />
        </section>

        {/* 8. Les 10 Grands Systèmes Corporels */}
        <section id="systemes" className="space-y-6 pt-4 border-t border-slate-900">
          <SystemsExplorer />
        </section>

        {/* 9. Conclusion & Intégration Physiologique (Slide 43) */}
        <section className="bg-gradient-to-r from-teal-950/40 via-slate-900 to-indigo-950/40 border border-teal-500/30 rounded-3xl p-8 md:p-10 space-y-6 shadow-2xl">
          <div className="max-w-3xl space-y-3">
            <span className="text-xs uppercase font-bold tracking-widest text-teal-400">
              Diapositive 43 · Synthèse Intégrative Finale
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white leading-tight">
              « {CONCLUSION_INTEGRATION.quote} »
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              L'organisme humain ne constitue pas une simple juxtaposition d'organes isolés, mais un système hyper-coordonné régi par l'homéostasie.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-slate-800">
            {CONCLUSION_INTEGRATION.pillars.map((pillar, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between">
                <div>
                  <h4 className="font-bold text-white text-sm mb-2">{pillar.title}</h4>
                  <p className="text-xs text-slate-300 leading-relaxed">{pillar.description}</p>
                </div>
                <div className="mt-4 pt-2 border-t border-slate-800/80 flex items-center gap-1.5 flex-wrap">
                  {pillar.systems.map((s, i) => (
                    <span key={i} className="text-[10px] bg-slate-900 text-teal-300 px-2 py-0.5 rounded border border-slate-800">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 10. Auto-Évaluation & QCM interactif */}
        <section id="quiz" className="space-y-6 pt-4 border-t border-slate-900">
          <QuizModule />
        </section>
      </main>

      {/* Footer */}
      <footer className="w-full bg-slate-950 border-t border-slate-900 py-8 px-4 sm:px-6 lg:px-8 mt-20">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            <span className="font-semibold text-slate-300">Anatomie & Physiologie Humaine</span>
            <span className="mx-2">·</span>
            <span>{COURSE_METADATA.university} ({COURSE_METADATA.faculty})</span>
          </div>
          <div>
            <span>Enseignant : {COURSE_METADATA.professor} · Année {COURSE_METADATA.academicYear}</span>
          </div>
        </div>
      </footer>

      {/* Global Modals */}
      <GlossaryModal isOpen={isGlossaryOpen} onClose={() => setIsGlossaryOpen(false)} />
      <CourseSummaryModal isOpen={isSummaryOpen} onClose={() => setIsSummaryOpen(false)} />
    </div>
  );
}
