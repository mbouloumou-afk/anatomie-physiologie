import React, { useState } from 'react';
import { REAL_PHOTOS_GALLERY } from '../data/courseData';
import { Camera, ZoomIn, X, Info, Sparkles, Microchip, Layers } from 'lucide-react';

export const RealPhotosGallery: React.FC = () => {
  const [selectedPhoto, setSelectedPhoto] = useState<typeof REAL_PHOTOS_GALLERY[0] | null>(null);
  const [activeFilter, setActiveFilter] = useState<'all' | 'cell' | 'organs' | 'tissues'>('all');

  const filteredPhotos = REAL_PHOTOS_GALLERY.filter((photo) => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'cell') return photo.id === 'tem_cell';
    if (activeFilter === 'organs') return photo.id === 'real_heart' || photo.id === 'real_brain';
    if (activeFilter === 'tissues') return photo.id === 'real_lungs' || photo.id === 'real_skin' || photo.id === 'stomach_histology';
    return true;
  });

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs uppercase font-bold tracking-wider text-emerald-400">
              Atlas Photographique Réel & Microscopie
            </span>
          </div>
          <h3 className="text-2xl font-bold text-white mt-1">
            Vraies Photographies Médicales & Électroniques
          </h3>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Confrontation directe des modélisations 3D avec les véritables clichés scientifiques : microscopie électronique à transmission (TEM), préparations histologiques de tissus humains et dissections anatomiques d'organes.
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 flex-wrap">
          {[
            { id: 'all', label: 'Toutes les photos réelles' },
            { id: 'cell', label: 'Cellule (TEM)' },
            { id: 'organs', label: 'Organes réels' },
            { id: 'tissues', label: 'Lames histologiques' },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setActiveFilter(f.id as any)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeFilter === f.id
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Real Photos */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPhotos.map((photo) => (
          <div
            key={photo.id}
            onClick={() => setSelectedPhoto(photo)}
            className="group cursor-pointer bg-slate-950 border border-slate-800 hover:border-emerald-500/60 rounded-2xl overflow-hidden shadow-lg transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between"
          >
            <div className="relative aspect-[4/3] overflow-hidden bg-slate-900">
              <img
                src={photo.image}
                alt={photo.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent opacity-80 group-hover:opacity-60 transition-opacity" />

              {/* Magnification pill badge */}
              <div className="absolute top-3 left-3 bg-slate-950/90 border border-emerald-500/40 px-2.5 py-1 rounded-md text-[10px] font-mono text-emerald-300 backdrop-blur-md">
                {photo.magnification}
              </div>

              {/* Click to zoom indicator */}
              <div className="absolute bottom-3 right-3 w-8 h-8 rounded-lg bg-slate-900/90 border border-slate-700 text-slate-200 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-sm">
                <ZoomIn className="w-4 h-4 text-emerald-400" />
              </div>
            </div>

            <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-400 block">
                  {photo.subject}
                </span>
                <h4 className="text-base font-bold text-white group-hover:text-emerald-200 transition-colors mt-0.5">
                  {photo.title}
                </h4>
                <p className="text-xs text-slate-400 mt-2 line-clamp-3 leading-relaxed">
                  {photo.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
                <span className="truncate">{photo.slideRef}</span>
                <span className="text-emerald-400 font-semibold group-hover:underline">Agrandir</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Lightbox Modal for detailed inspection */}
      {selectedPhoto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-4xl max-h-[92vh] overflow-y-auto flex flex-col shadow-2xl relative">
            <button
              onClick={() => setSelectedPhoto(null)}
              className="absolute top-4 right-4 z-10 p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* High-res image display */}
            <div className="relative w-full aspect-video bg-black flex items-center justify-center overflow-hidden rounded-t-3xl">
              <img
                src={selectedPhoto.image}
                alt={selectedPhoto.title}
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-3 left-4 bg-slate-950/80 border border-emerald-500/40 px-3 py-1.5 rounded-lg text-xs font-mono text-emerald-300 backdrop-blur-md">
                {selectedPhoto.magnification}
              </div>
            </div>

            {/* Scientific details */}
            <div className="p-6 md:p-8 space-y-4">
              <div>
                <span className="text-xs uppercase font-bold tracking-wider text-emerald-400">
                  {selectedPhoto.subject} · {selectedPhoto.slideRef}
                </span>
                <h3 className="text-2xl font-bold text-white mt-1">{selectedPhoto.title}</h3>
              </div>

              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300 leading-relaxed">
                <h4 className="font-semibold text-white mb-1.5 flex items-center gap-1.5">
                  <Info className="w-4 h-4 text-emerald-400" />
                  Description Scientifique & Corrélation au Cours
                </h4>
                <p>{selectedPhoto.description}</p>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-800 text-xs text-slate-500">
                <span>Faculté Mohammed VI des Sciences Infirmières et Professions de la Santé</span>
                <button
                  onClick={() => setSelectedPhoto(null)}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl transition-colors"
                >
                  Fermer l'agrandissement
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
