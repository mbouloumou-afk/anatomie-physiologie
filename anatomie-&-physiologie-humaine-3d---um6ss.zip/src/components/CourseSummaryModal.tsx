import React from 'react';
import { COURSE_METADATA, DEFINITIONS, HIERARCHY_LEVELS, ORGANELLES, TISSUES, STOMACH_ORGAN_EXAMPLE, HUMAN_SYSTEMS, CONCLUSION_INTEGRATION } from '../data/courseData';
import { X, Printer, CheckCircle2, Bookmark } from 'lucide-react';

interface CourseSummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CourseSummaryModal: React.FC<CourseSummaryModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200 print:p-0 print:bg-white">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden print:bg-white print:text-black print:border-none print:max-h-none print:shadow-none">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center">
              <Bookmark className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Fiche Complète de Révision du Module</h3>
              <p className="text-xs text-slate-400">Synthèse officielle pour les examens et concours UM6SS</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Imprimer</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Document Content */}
        <div className="p-6 md:p-8 overflow-y-auto space-y-8 text-xs leading-relaxed print:p-0 print:space-y-4">
          {/* Institution Header */}
          <div className="border-b border-slate-800 pb-4 text-center print:border-black">
            <h2 className="text-xl font-bold text-white print:text-black">
              {COURSE_METADATA.university}
            </h2>
            <p className="text-xs text-slate-400 print:text-gray-600 mt-1">
              {COURSE_METADATA.faculty}
            </p>
            <div className="mt-3 flex items-center justify-center gap-4 text-[11px] text-teal-400 print:text-black font-semibold flex-wrap">
              <span>{COURSE_METADATA.module}</span>
              <span>·</span>
              <span>Filière {COURSE_METADATA.filiere}</span>
              <span>·</span>
              <span>Option : {COURSE_METADATA.options}</span>
              <span>·</span>
              <span>{COURSE_METADATA.professor}</span>
              <span>·</span>
              <span>{COURSE_METADATA.academicYear}</span>
            </div>
          </div>

          {/* Section 1: Définitions Fondamentales */}
          <div>
            <h3 className="text-sm font-bold text-white print:text-black uppercase tracking-wider mb-3">
              1. Définitions Fondamentales (Slide 5)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 print:border-gray-300 print:bg-gray-50">
                <span className="font-bold text-teal-300 print:text-black text-sm block mb-1">
                  Anatomie
                </span>
                <p className="text-slate-300 print:text-gray-800">
                  {DEFINITIONS.anatomie.definition}
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 print:border-gray-300 print:bg-gray-50">
                <span className="font-bold text-teal-300 print:text-black text-sm block mb-1">
                  Physiologie
                </span>
                <p className="text-slate-300 print:text-gray-800">
                  {DEFINITIONS.physiologie.definition}
                </p>
              </div>
            </div>
          </div>

          {/* Section 2: Organisation Hiérarchique */}
          <div>
            <h3 className="text-sm font-bold text-white print:text-black uppercase tracking-wider mb-3">
              2. Organisation du Corps Humain (Slide 6 & 42)
            </h3>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 print:border-gray-300 print:bg-gray-50">
              <p className="text-slate-300 print:text-gray-800 font-semibold mb-3">
                Organisme extrêmement complexe qui comporte des milliards de cellules associées pour former :
                des tissus → des organes → des appareils ou systèmes → un mécanisme évolué d'organisation et de fonctionnement.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 text-center text-[11px]">
                {HIERARCHY_LEVELS.map((lvl) => (
                  <div key={lvl.id} className="p-2 rounded-lg bg-slate-900 border border-slate-800 print:border-gray-300 print:bg-white">
                    <span className="text-[10px] text-teal-400 print:text-black font-bold block">Niveau {lvl.level}</span>
                    <strong className="text-white print:text-black">{lvl.title}</strong>
                    <span className="text-[10px] text-slate-500 print:text-gray-600 block mt-1">{lvl.count}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Section 3: La Cellule et les Organites */}
          <div>
            <h3 className="text-sm font-bold text-white print:text-black uppercase tracking-wider mb-3">
              3. La Cellule Eucaryote & Organites (Slides 7-18)
            </h3>
            <p className="text-slate-400 print:text-gray-700 mb-3">
              Unité fondamentale, structurale et fonctionnelle (100 000 milliards de cellules). Eucaryote car possède un noyau bien défini et des organites compartimentés.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {ORGANELLES.map((org) => (
                <div key={org.id} className="p-3 rounded-lg bg-slate-950 border border-slate-800 print:border-gray-300 print:bg-white">
                  <div className="font-bold text-white print:text-black flex items-center justify-between">
                    <span>{org.name}</span>
                    <span className="text-[10px] text-teal-400 print:text-gray-600">{org.id}</span>
                  </div>
                  <p className="text-slate-300 print:text-gray-700 text-[11px] mt-1">{org.function}</p>
                  {org.courseNote && (
                    <span className="text-[10px] text-slate-500 print:text-gray-500 italic block mt-1">
                      {org.courseNote}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Section 4: Transports Membranaires */}
          <div>
            <h3 className="text-sm font-bold text-white print:text-black uppercase tracking-wider mb-3">
              4. Transports Membranaires (Slide 11)
            </h3>
            <div className="space-y-2">
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 print:border-gray-300">
                <strong className="text-teal-300 print:text-black block">1. Transports passifs</strong>
                <p className="text-slate-300 print:text-gray-700 text-[11px]">
                  Ne nécessitent pas d'énergie, selon la différence de concentration de part et d'autre (du + vers le -). Diffusion simple (osmose) et diffusion facilitée (protéine transmembranaire canal ionique ou perméase).
                </p>
              </div>
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 print:border-gray-300">
                <strong className="text-teal-300 print:text-black block">2. Transports actifs</strong>
                <p className="text-slate-300 print:text-gray-700 text-[11px]">
                  Nécessitent de l'énergie sous forme d'ATP, contre le gradient de concentration, grâce à une protéine dite « pompe » (protons, Na+, Ca++).
                </p>
              </div>
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 print:border-gray-300">
                <strong className="text-teal-300 print:text-black block">3. Transports vésiculaires</strong>
                <p className="text-slate-300 print:text-gray-700 text-[11px]">
                  Endocytose : invagination membranaire (Phagocytose pour solides, Pinocytose pour liquides). Exocytose : fusion des vacuoles pour excréter.
                </p>
              </div>
            </div>
          </div>

          {/* Section 5: Les 4 Tissus et L'Organe */}
          <div>
            <h3 className="text-sm font-bold text-white print:text-black uppercase tracking-wider mb-3">
              5. Les 4 Tissus & L'Organe (Slides 23-30)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-4">
              {TISSUES.map((t) => (
                <div key={t.id} className="p-3 rounded-lg bg-slate-950 border border-slate-800 print:border-gray-300">
                  <strong className="text-white print:text-black block">{t.name.split(' (')[0]}</strong>
                  <p className="text-slate-400 print:text-gray-700 text-[10px] mt-1">{t.role}</p>
                </div>
              ))}
            </div>
            <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 print:border-gray-300">
              <strong className="text-teal-300 print:text-black block mb-1">
                L'exemple clé de l'Estomac (Slide 30) :
              </strong>
              <p className="text-slate-300 print:text-gray-800 text-[11px]">
                {STOMACH_ORGAN_EXAMPLE.description} Épithélial (muqueuse), Musculaire lisse (brassage), Conjonctif (soutien/vaisseaux), Nerveux (coordination).
              </p>
            </div>
          </div>

          {/* Section 6: Conclusion Fondamentale */}
          <div className="p-4 rounded-xl bg-teal-950/40 border border-teal-500/40 print:border-black print:bg-gray-100">
            <h3 className="text-sm font-bold text-teal-300 print:text-black uppercase tracking-wider mb-2">
              Conclusion & Homéostasie (Slide 43)
            </h3>
            <p className="text-sm font-bold text-white print:text-black mb-2">
              « {CONCLUSION_INTEGRATION.quote} »
            </p>
            <p className="text-slate-300 print:text-gray-700 text-[11px]">
              Exemples : Le système digestif et respiratoire apportent nutriments et O2 au sang qui les distribue aux cellules. Le système urinaire et respiratoire éliminent les déchets métaboliques de l'organisme.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs text-slate-500 print:hidden">
          <span>Plateforme interactive 3D UM6SS</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg font-medium"
          >
            Fermer la fiche
          </button>
        </div>
      </div>
    </div>
  );
};
