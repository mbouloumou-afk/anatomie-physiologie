import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { ORGANELLES, OrganelleInfo, IMAGES } from '../../data/courseData';
import { Eye, Info, RotateCcw, ZoomIn, ZoomOut, CheckCircle2, Camera } from 'lucide-react';

interface Cell3DSceneProps {
  selectedOrganelleId?: string;
  onSelectOrganelle?: (organelle: OrganelleInfo) => void;
}

export const Cell3DScene: React.FC<Cell3DSceneProps> = ({
  selectedOrganelleId = 'noyau',
  onSelectOrganelle,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const reqIdRef = useRef<number | null>(null);
  const cellGroupRef = useRef<THREE.Group | null>(null);
  const organelleMeshesRef = useRef<Map<string, THREE.Object3D>>(new Map());

  const [activeOrganelle, setActiveOrganelle] = useState<OrganelleInfo>(
    ORGANELLES.find((o) => o.id === selectedOrganelleId) || ORGANELLES[0]
  );
  const [hoveredName, setHoveredName] = useState<string | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 550;

    // SCENE
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // CAMERA
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 1.2, 5.8);
    cameraRef.current = camera;

    // RENDERER
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // LIGHTING
    scene.add(new THREE.AmbientLight(0x38bdf8, 0.45));
    const mainLight = new THREE.DirectionalLight(0xffffff, 1.3);
    mainLight.position.set(5, 7, 6);
    scene.add(mainLight);

    const rimLight = new THREE.DirectionalLight(0x818cf8, 0.8);
    rimLight.position.set(-6, -4, -4);
    scene.add(rimLight);

    const pointLight = new THREE.PointLight(0x6366f1, 1.5, 8);
    pointLight.position.set(0, 0, 0);
    scene.add(pointLight);

    // ROOT CELL GROUP
    const cellGroup = new THREE.Group();
    cellGroupRef.current = cellGroup;
    scene.add(cellGroup);

    // --- 1. OUTER CELL MEMBRANE (Bicouche Phospholipidique en coupe 3/4) ---
    // Translucent hemisphere cutaway
    const membraneGeom = new THREE.SphereGeometry(2.4, 48, 48, 0, Math.PI * 1.6, 0, Math.PI * 0.9);
    const membraneMat = new THREE.MeshPhysicalMaterial({
      color: 0x0284c7,
      transparent: true,
      opacity: 0.22,
      roughness: 0.2,
      transmission: 0.5,
      ior: 1.25,
      side: THREE.DoubleSide,
    });
    const membraneMesh = new THREE.Mesh(membraneGeom, membraneMat);
    cellGroup.add(membraneMesh);

    // Cytoplasm Glow background
    const cytosolGeom = new THREE.SphereGeometry(2.25, 32, 32, 0, Math.PI * 1.55);
    const cytosolMat = new THREE.MeshBasicMaterial({
      color: 0x0f172a,
      transparent: true,
      opacity: 0.4,
      side: THREE.BackSide,
    });
    cellGroup.add(new THREE.Mesh(cytosolGeom, cytosolMat));

    // --- 2. NOYAU (Nucleus with cutaway, nucleolus, pores) ---
    const nucleusGroup = new THREE.Group();
    nucleusGroup.position.set(-0.25, 0.1, 0.1);
    nucleusGroup.userData = { id: 'noyau', name: 'Noyau Cellulaire' };
    organelleMeshesRef.current.set('noyau', nucleusGroup);
    cellGroup.add(nucleusGroup);

    // Double membrane envelope (cutaway)
    const envelopeGeom = new THREE.SphereGeometry(0.85, 32, 32, 0, Math.PI * 1.5);
    const envelopeMat = new THREE.MeshStandardMaterial({
      color: 0x6366f1,
      roughness: 0.35,
      metalness: 0.1,
      side: THREE.DoubleSide,
    });
    const envelopeMesh = new THREE.Mesh(envelopeGeom, envelopeMat);
    nucleusGroup.add(envelopeMesh);

    // Nucleolus (core)
    const nucleolusGeom = new THREE.SphereGeometry(0.32, 24, 24);
    const nucleolusMat = new THREE.MeshStandardMaterial({
      color: 0xa855f7,
      emissive: 0x7e22ce,
      emissiveIntensity: 0.4,
      roughness: 0.3,
    });
    const nucleolusMesh = new THREE.Mesh(nucleolusGeom, nucleolusMat);
    nucleolusMesh.position.set(-0.05, 0.05, 0.05);
    nucleusGroup.add(nucleolusMesh);

    // Chromatin DNA threads (Torus knots)
    const chromatinGeom = new THREE.TorusKnotGeometry(0.48, 0.025, 64, 8, 2, 5);
    const chromatinMat = new THREE.MeshStandardMaterial({
      color: 0x818cf8,
      wireframe: true,
      transparent: true,
      opacity: 0.6,
    });
    nucleusGroup.add(new THREE.Mesh(chromatinGeom, chromatinMat));

    // --- 3. MITOCHONDRIES (Beans with inner cristae) ---
    const mitoPositions = [
      { pos: [1.2, 0.8, 0.4], rot: [0.4, 0.3, 0.2] },
      { pos: [-1.2, -0.9, 0.6], rot: [-0.3, 0.8, -0.4] },
      { pos: [0.9, -1.1, -0.2], rot: [0.6, -0.4, 0.5] },
    ];

    const mitochondriaGroup = new THREE.Group();
    mitochondriaGroup.userData = { id: 'mitochondrie', name: 'Mitochondrie' };
    organelleMeshesRef.current.set('mitochondrie', mitochondriaGroup);
    cellGroup.add(mitochondriaGroup);

    mitoPositions.forEach(({ pos, rot }) => {
      const singleMito = new THREE.Group();
      singleMito.position.set(pos[0], pos[1], pos[2]);
      singleMito.rotation.set(rot[0], rot[1], rot[2]);

      // Outer capsule
      const mitoGeom = new THREE.CapsuleGeometry(0.2, 0.45, 12, 16);
      const mitoMat = new THREE.MeshStandardMaterial({
        color: 0xef4444,
        roughness: 0.3,
        emissive: 0xb91c1c,
        emissiveIntensity: 0.2,
      });
      singleMito.add(new THREE.Mesh(mitoGeom, mitoMat));

      // Inner cristae ridges
      for (let c = -0.2; c <= 0.2; c += 0.1) {
        const cristaGeom = new THREE.CylinderGeometry(0.16, 0.16, 0.02, 12);
        const cristaMat = new THREE.MeshStandardMaterial({ color: 0xfca5a5 });
        const crista = new THREE.Mesh(cristaGeom, cristaMat);
        crista.position.set(0, c, 0);
        crista.rotation.x = Math.PI / 2;
        singleMito.add(crista);
      }

      mitochondriaGroup.add(singleMito);
    });

    // --- 4. RÉTICULUM ENDOPLASMIQUE (REG et REL) ---
    // REG: Rough ER folds around nucleus with ribosomes
    const regGroup = new THREE.Group();
    regGroup.position.set(-0.3, 0.95, -0.1);
    regGroup.userData = { id: 're_granuleux', name: 'RE Granuleux (REG)' };
    organelleMeshesRef.current.set('re_granuleux', regGroup);
    cellGroup.add(regGroup);

    for (let f = 0; f < 3; f++) {
      const foldGeom = new THREE.TorusGeometry(0.8 + f * 0.18, 0.05, 8, 24, Math.PI * 0.8);
      const foldMat = new THREE.MeshStandardMaterial({ color: 0x8b5cf6, roughness: 0.4 });
      const fold = new THREE.Mesh(foldGeom, foldMat);
      fold.rotation.x = Math.PI / 2 + f * 0.2;
      fold.rotation.z = f * 0.3;
      regGroup.add(fold);

      // Ribosomes studs
      for (let r = 0; r < 8; r++) {
        const dotGeom = new THREE.SphereGeometry(0.025, 6, 6);
        const dot = new THREE.Mesh(dotGeom, new THREE.MeshBasicMaterial({ color: 0x38bdf8 }));
        const angle = (r / 8) * Math.PI * 0.8;
        dot.position.set(Math.cos(angle) * (0.8 + f * 0.18), Math.sin(angle) * (0.8 + f * 0.18), 0.06);
        regGroup.add(dot);
      }
    }

    // REL: Smooth ER tubular network
    const relGroup = new THREE.Group();
    relGroup.position.set(-1.1, 0.4, -0.4);
    relGroup.userData = { id: 're_lisse', name: 'RE Lisse (REL)' };
    organelleMeshesRef.current.set('re_lisse', relGroup);
    cellGroup.add(relGroup);

    for (let t = 0; t < 4; t++) {
      const tubuleGeom = new THREE.TorusGeometry(0.24, 0.04, 8, 16);
      const tubuleMat = new THREE.MeshStandardMaterial({ color: 0xec4899, roughness: 0.3 });
      const tubule = new THREE.Mesh(tubuleGeom, tubuleMat);
      tubule.position.set((t % 2) * 0.22, Math.floor(t / 2) * 0.22, 0);
      tubule.rotation.set(t * 0.5, t * 0.4, 0);
      relGroup.add(tubule);
    }

    // --- 5. APPAREIL DE GOLGI (Stacked cisternae saccules) ---
    const golgiGroup = new THREE.Group();
    golgiGroup.position.set(1.15, -0.2, 0.3);
    golgiGroup.userData = { id: 'golgi', name: 'Appareil de Golgi' };
    organelleMeshesRef.current.set('golgi', golgiGroup);
    cellGroup.add(golgiGroup);

    for (let g = 0; g < 5; g++) {
      const sacculeGeom = new THREE.TorusGeometry(0.42, 0.05 - g * 0.005, 8, 20, Math.PI * 0.65);
      const sacculeMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.35 });
      const saccule = new THREE.Mesh(sacculeGeom, sacculeMat);
      saccule.position.set(0, g * 0.09 - 0.2, 0);
      saccule.rotation.z = Math.PI * 0.2;
      saccule.rotation.x = 0.3;
      golgiGroup.add(saccule);
    }
    // Budding vesicles
    for (let v = 0; v < 4; v++) {
      const vesGeom = new THREE.SphereGeometry(0.045, 12, 12);
      const vesMat = new THREE.MeshStandardMaterial({ color: 0xfbbf24 });
      const ves = new THREE.Mesh(vesGeom, vesMat);
      ves.position.set(0.35 + (v % 2) * 0.1, -0.15 + v * 0.1, 0.1);
      golgiGroup.add(ves);
    }

    // --- 6. LYSOSOMES (Spheres with hydrolase interior) ---
    const lysosomeGroup = new THREE.Group();
    lysosomeGroup.userData = { id: 'lysosome', name: 'Lysosomes' };
    organelleMeshesRef.current.set('lysosome', lysosomeGroup);
    cellGroup.add(lysosomeGroup);

    [
      [0.6, 1.3, 0.1],
      [-0.8, -1.2, 0.4],
      [1.3, -0.8, -0.4],
    ].forEach(([x, y, z]) => {
      const lysoGeom = new THREE.SphereGeometry(0.12, 16, 16);
      const lysoMat = new THREE.MeshStandardMaterial({
        color: 0x10b981,
        roughness: 0.2,
        emissive: 0x059669,
        emissiveIntensity: 0.3,
      });
      const lysoMesh = new THREE.Mesh(lysoGeom, lysoMat);
      lysoMesh.position.set(x, y, z);
      lysosomeGroup.add(lysoMesh);
    });

    // --- 7. CENTROSOMES (2 Perpendicular Centrioles) ---
    const centroGroup = new THREE.Group();
    centroGroup.position.set(-0.7, 0.8, 0.5);
    centroGroup.userData = { id: 'centrosome', name: 'Centrosome (2 Centrioles)' };
    organelleMeshesRef.current.set('centrosome', centroGroup);
    cellGroup.add(centroGroup);

    // Centriole 1
    const centriole1Geom = new THREE.CylinderGeometry(0.06, 0.06, 0.24, 9, 1, true);
    const centrioleMat = new THREE.MeshStandardMaterial({ color: 0x3b82f6, metalness: 0.4, roughness: 0.3 });
    const c1 = new THREE.Mesh(centriole1Geom, centrioleMat);
    centroGroup.add(c1);

    // Centriole 2 (Perpendicular 90°)
    const c2 = new THREE.Mesh(centriole1Geom, centrioleMat);
    c2.rotation.x = Math.PI / 2;
    c2.position.set(0.12, 0.06, 0);
    centroGroup.add(c2);

    // --- 8. RIBOSOMES PARTICLES (Free in cytoplasm) ---
    const riboGroup = new THREE.Group();
    riboGroup.userData = { id: 'ribosome', name: 'Ribosomes Libres' };
    organelleMeshesRef.current.set('ribosome', riboGroup);
    cellGroup.add(riboGroup);

    const riboCount = 150;
    const riboGeom = new THREE.BufferGeometry();
    const riboPositions = new Float32Array(riboCount * 3);
    for (let i = 0; i < riboCount; i++) {
      const radius = 0.9 + Math.random() * 1.1;
      const theta = Math.random() * Math.PI * 1.5;
      const phi = Math.acos(2 * Math.random() - 1);
      riboPositions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      riboPositions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      riboPositions[i * 3 + 2] = radius * Math.cos(phi);
    }
    riboGeom.setAttribute('position', new THREE.BufferAttribute(riboPositions, 3));
    const riboMat = new THREE.PointsMaterial({ color: 0x06b6d4, size: 0.04 });
    riboGroup.add(new THREE.Points(riboGeom, riboMat));

    // --- 9. VACUOLES ---
    const vacuoleGroup = new THREE.Group();
    vacuoleGroup.userData = { id: 'vacuole', name: 'Vacuoles' };
    organelleMeshesRef.current.set('vacuole', vacuoleGroup);
    cellGroup.add(vacuoleGroup);

    [
      [0.3, -1.2, 0.5],
      [-1.3, 0.2, 0.2],
    ].forEach(([vx, vy, vz]) => {
      const vacMesh = new THREE.Mesh(
        new THREE.SphereGeometry(0.15, 16, 16),
        new THREE.MeshPhysicalMaterial({ color: 0x14b8a6, transparent: true, opacity: 0.65, roughness: 0.1 })
      );
      vacMesh.position.set(vx, vy, vz);
      vacuoleGroup.add(vacMesh);
    });

    // Raycasting for organelle selection
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const handlePointerDown = (event: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const interactiveGroups = Array.from(organelleMeshesRef.current.values());
      const intersects = raycaster.intersectObjects(interactiveGroups, true);

      if (intersects.length > 0) {
        let currentObj: THREE.Object3D | null = intersects[0].object;
        while (currentObj && !currentObj.userData?.id && currentObj.parent !== cellGroup) {
          currentObj = currentObj.parent;
        }
        if (currentObj && currentObj.userData?.id) {
          const found = ORGANELLES.find((o) => o.id === currentObj?.userData.id);
          if (found) {
            setActiveOrganelle(found);
            onSelectOrganelle?.(found);
          }
        }
      }
    };

    const handlePointerMove = (event: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const interactiveGroups = Array.from(organelleMeshesRef.current.values());
      const intersects = raycaster.intersectObjects(interactiveGroups, true);

      if (intersects.length > 0) {
        let currentObj: THREE.Object3D | null = intersects[0].object;
        while (currentObj && !currentObj.userData?.id && currentObj.parent !== cellGroup) {
          currentObj = currentObj.parent;
        }
        if (currentObj && currentObj.userData?.name) {
          setHoveredName(currentObj.userData.name);
          return;
        }
      }
      setHoveredName(null);
    };

    renderer.domElement.addEventListener('pointerdown', handlePointerDown);
    renderer.domElement.addEventListener('pointermove', handlePointerMove);

    // Orbit mouse rotation
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging || !cellGroup) return;
      const deltaX = e.clientX - prevMouseX;
      const deltaY = e.clientY - prevMouseY;
      cellGroup.rotation.y += deltaX * 0.007;
      cellGroup.rotation.x = Math.max(-0.6, Math.min(0.6, cellGroup.rotation.x + deltaY * 0.005));
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseUp = () => (isDragging = false);

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      camera.position.z = Math.max(3.0, Math.min(8.5, camera.position.z + e.deltaY * 0.004));
    };

    container.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    container.addEventListener('wheel', onWheel, { passive: false });

    // RENDER ANIMATION
    let clock = new THREE.Clock();

    const animate = () => {
      reqIdRef.current = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // Soft natural drift
      if (!isDragging && cellGroup) {
        cellGroup.rotation.y += 0.002;
      }

      // Pulse active selected organelle
      const selectedMesh = organelleMeshesRef.current.get(selectedOrganelleId);
      if (selectedMesh) {
        const pulse = 1 + 0.06 * Math.sin(elapsed * 4);
        selectedMesh.scale.set(pulse, pulse, pulse);
      }

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      if (reqIdRef.current) cancelAnimationFrame(reqIdRef.current);
      renderer.domElement.removeEventListener('pointerdown', handlePointerDown);
      renderer.domElement.removeEventListener('pointermove', handlePointerMove);
      container.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      container.removeEventListener('wheel', onWheel);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, [selectedOrganelleId]);

  const handleSelectTab = (organelle: OrganelleInfo) => {
    setActiveOrganelle(organelle);
    onSelectOrganelle?.(organelle);

    // Zoom camera slightly to focus
    if (cameraRef.current && cellGroupRef.current) {
      const mesh = organelleMeshesRef.current.get(organelle.id);
      if (mesh) {
        // Soft camera tilt
        cameraRef.current.position.set(0, 0.8, 5.2);
      }
    }
  };

  const handleReset = () => {
    if (cellGroupRef.current) {
      cellGroupRef.current.rotation.set(0, 0, 0);
    }
    if (cameraRef.current) {
      cameraRef.current.position.set(0, 1.2, 5.8);
    }
  };

  return (
    <div className="flex flex-col xl:flex-row gap-6 items-stretch">
      {/* 3D WebGL Canvas */}
      <div className="relative flex-1 min-h-[500px] h-[580px] bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl flex flex-col">
        {/* Top Info overlay */}
        <div className="absolute top-4 left-4 z-10 pointer-events-none">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
            <span className="text-xs font-semibold tracking-wider uppercase text-cyan-400">
              Modèle 3D Cellule Eucaryote (Coupe Ultrastructure)
            </span>
          </div>
          <p className="text-xs text-slate-400 max-w-xs mt-1">
            Cliquez sur un organite dans la scène 3D ou sélectionnez dans la liste ci-dessous.
          </p>
          {hoveredName && (
            <div className="mt-2 inline-flex items-center gap-2 px-3 py-1 bg-slate-900/90 border border-cyan-500/40 rounded-md text-xs text-cyan-300 font-medium backdrop-blur-md">
              <Info className="w-3.5 h-3.5" />
              <span>{hoveredName}</span>
            </div>
          )}
        </div>

        {/* Viewport controls */}
        <div className="absolute top-4 right-4 z-10 flex items-center gap-1.5 bg-slate-900/85 backdrop-blur-md border border-slate-800 p-1.5 rounded-xl shadow-lg">
          <button
            onClick={() => {
              if (cameraRef.current) cameraRef.current.position.z = Math.max(3.0, cameraRef.current.position.z - 0.8);
            }}
            title="Zoom +"
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              if (cameraRef.current) cameraRef.current.position.z = Math.min(8.5, cameraRef.current.position.z + 0.8);
            }}
            title="Zoom -"
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={handleReset}
            title="Réinitialiser"
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Canvas DOM */}
        <div ref={containerRef} className="w-full flex-1 cursor-grab active:cursor-grabbing" />

        {/* Organelles Bottom Quick Bar */}
        <div className="absolute bottom-3 left-3 right-3 z-10 flex items-center gap-1.5 overflow-x-auto p-2 bg-slate-950/80 backdrop-blur-md rounded-xl border border-slate-800/80">
          {ORGANELLES.map((org) => (
            <button
              key={org.id}
              onClick={() => handleSelectTab(org)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-all flex items-center gap-1.5 ${
                activeOrganelle.id === org.id
                  ? 'bg-cyan-500 text-slate-950 font-semibold shadow-md'
                  : 'bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
              }`}
            >
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: org.color }} />
              {org.name.split(' ')[0]}
            </button>
          ))}
        </div>
      </div>

      {/* Detail Pedagogical Deck for the Selected Organelle */}
      <div className="w-full xl:w-[420px] bg-slate-900/90 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between shadow-xl">
        <div>
          {/* Header */}
          <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <span className="text-xs uppercase tracking-wider font-semibold text-cyan-400">
                Fiche d'Organite Eucaryote
              </span>
              <h3 className="text-2xl font-bold text-white mt-1 flex items-center gap-2">
                <span className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: activeOrganelle.color }} />
                {activeOrganelle.name}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">{activeOrganelle.frenchSubtitle}</p>
            </div>
          </div>

          {/* Real TEM micrograph comparison banner */}
          <div className="mt-4 p-2.5 bg-slate-950 border border-slate-800 rounded-xl flex items-center gap-3">
            <img
              src={IMAGES.realCellTem}
              alt="Microscopie électronique TEM réelle"
              className="w-16 h-12 rounded-lg object-cover border border-slate-700 shrink-0"
              referrerPolicy="no-referrer"
            />
            <div className="text-[11px] text-slate-400">
              <span className="font-semibold text-emerald-400 flex items-center gap-1">
                <Camera className="w-3 h-3" />
                Vraie Photo TEM (x 45 000)
              </span>
              <span>Visualisation réelle des organites et membranes en ultrastructure.</span>
            </div>
          </div>

          {/* Slide Quote highlight */}
          {activeOrganelle.courseNote && (
            <div className="mt-4 p-3 bg-teal-950/40 border border-teal-500/30 rounded-xl text-xs text-teal-200 leading-relaxed">
              <span className="font-semibold text-teal-300">Extrait du cours UM6SS : </span>
              {activeOrganelle.courseNote}
            </div>
          )}

          {/* Structure */}
          <div className="mt-5 space-y-4 text-xs">
            <div>
              <h4 className="text-slate-300 font-semibold uppercase tracking-wider text-[11px] mb-1">
                Structure & Composition
              </h4>
              <p className="text-slate-400 leading-relaxed bg-slate-950/60 p-3 rounded-lg border border-slate-800/80">
                {activeOrganelle.structure}
              </p>
            </div>

            {/* Function */}
            <div>
              <h4 className="text-slate-300 font-semibold uppercase tracking-wider text-[11px] mb-1">
                Rôle & Fonction Physiologique
              </h4>
              <p className="text-slate-300 leading-relaxed bg-cyan-950/30 p-3 rounded-lg border border-cyan-800/40 font-medium">
                {activeOrganelle.function}
              </p>
            </div>

            {/* Key bullet details */}
            <div>
              <h4 className="text-slate-300 font-semibold uppercase tracking-wider text-[11px] mb-1.5">
                Points Clés à Retenir
              </h4>
              <ul className="space-y-2">
                {activeOrganelle.details.map((detail, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-slate-300 leading-relaxed">
                    <CheckCircle2 className="w-3.5 h-3.5 text-teal-400 shrink-0 mt-0.5" />
                    <span>{detail}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Footer info note */}
        <div className="mt-6 pt-4 border-t border-slate-800 text-[11px] text-slate-500 flex items-center justify-between">
          <span>Module Anatomie-Physiologie · S1</span>
          <span className="text-cyan-400 font-medium">100 000 milliards de cellules</span>
        </div>
      </div>
    </div>
  );
};
