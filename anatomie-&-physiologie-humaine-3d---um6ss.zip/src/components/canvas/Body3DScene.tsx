import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Eye, Layers, RotateCcw, Heart, Play, Pause, ZoomIn, ZoomOut, Info } from 'lucide-react';

interface Body3DSceneProps {
  onSelectOrgan?: (organId: string) => void;
  selectedOrganId?: string | null;
}

export const Body3DScene: React.FC<Body3DSceneProps> = ({ onSelectOrgan, selectedOrganId }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const reqIdRef = useRef<number | null>(null);

  // Layer visibility state
  const [layers, setLayers] = useState({
    skin: true,
    skeleton: true,
    muscles: false,
    organs: true,
    vessels: true,
    nerves: true,
  });

  const [isPlaying, setIsPlaying] = useState(true);
  const [activePreset, setActivePreset] = useState<'full' | 'head' | 'thorax' | 'abdomen' | 'urinary'>('full');
  const [hoveredPart, setHoveredPart] = useState<string | null>(null);

  // References to animated 3D meshes
  const heartRef = useRef<THREE.Mesh | null>(null);
  const leftLungRef = useRef<THREE.Mesh | null>(null);
  const rightLungRef = useRef<THREE.Mesh | null>(null);
  const bloodParticlesRef = useRef<THREE.Points | null>(null);
  const nervePulsesRef = useRef<THREE.Points | null>(null);
  const groupBodyRef = useRef<THREE.Group | null>(null);

  // Group references for toggling layers
  const skinGroupRef = useRef<THREE.Group | null>(null);
  const skeletonGroupRef = useRef<THREE.Group | null>(null);
  const muscleGroupRef = useRef<THREE.Group | null>(null);
  const organsGroupRef = useRef<THREE.Group | null>(null);
  const vesselsGroupRef = useRef<THREE.Group | null>(null);
  const nervesGroupRef = useRef<THREE.Group | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 550;

    // SCENE
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.fog = new THREE.FogExp2(0x020617, 0.05);

    // CAMERA
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0, 7.5);
    cameraRef.current = camera;

    // RENDERER
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // LIGHTING (Studio Medical 3-Point Light)
    const ambientLight = new THREE.AmbientLight(0x38bdf8, 0.4);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.2);
    keyLight.position.set(5, 8, 6);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x0284c7, 0.6);
    fillLight.position.set(-5, 0, -4);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xec4899, 0.5);
    rimLight.position.set(0, -6, -4);
    scene.add(rimLight);

    // ROOT ANATOMY GROUP
    const bodyGroup = new THREE.Group();
    groupBodyRef.current = bodyGroup;
    scene.add(bodyGroup);

    // --- 1. SKIN / SILHOUETTE LAYER ---
    const skinGroup = new THREE.Group();
    skinGroupRef.current = skinGroup;
    bodyGroup.add(skinGroup);

    const skinMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.18,
      roughness: 0.2,
      transmission: 0.6,
      ior: 1.3,
      thickness: 0.5,
      depthWrite: false,
    });

    // Head
    const headGeom = new THREE.SphereGeometry(0.55, 32, 32);
    headGeom.scale(0.85, 1.15, 0.95);
    const headMesh = new THREE.Mesh(headGeom, skinMaterial);
    headMesh.position.set(0, 2.5, 0);
    skinGroup.add(headMesh);

    // Neck
    const neckGeom = new THREE.CylinderGeometry(0.24, 0.28, 0.45, 24);
    const neckMesh = new THREE.Mesh(neckGeom, skinMaterial);
    neckMesh.position.set(0, 1.8, 0);
    skinGroup.add(neckMesh);

    // Torso & Chest
    const torsoGeom = new THREE.CylinderGeometry(0.72, 0.55, 1.9, 32);
    torsoGeom.scale(1.1, 1, 0.65);
    const torsoMesh = new THREE.Mesh(torsoGeom, skinMaterial);
    torsoMesh.position.set(0, 0.7, 0);
    skinGroup.add(torsoMesh);

    // Pelvis
    const pelvisGeom = new THREE.CylinderGeometry(0.55, 0.48, 0.7, 24);
    pelvisGeom.scale(1.05, 1, 0.7);
    const pelvisMesh = new THREE.Mesh(pelvisGeom, skinMaterial);
    pelvisMesh.position.set(0, -0.6, 0);
    skinGroup.add(pelvisMesh);

    // Arms & Legs
    const limbMat = skinMaterial.clone();
    [-1, 1].forEach((side) => {
      // Upper arm
      const armGeom = new THREE.CylinderGeometry(0.16, 0.13, 1.1, 16);
      const arm = new THREE.Mesh(armGeom, limbMat);
      arm.position.set(side * 1.0, 0.95, 0);
      arm.rotation.z = side * -0.15;
      skinGroup.add(arm);

      // Forearm
      const forearmGeom = new THREE.CylinderGeometry(0.12, 0.09, 1.0, 16);
      const forearm = new THREE.Mesh(forearmGeom, limbMat);
      forearm.position.set(side * 1.25, -0.05, 0);
      forearm.rotation.z = side * -0.1;
      skinGroup.add(forearm);

      // Thigh
      const thighGeom = new THREE.CylinderGeometry(0.24, 0.17, 1.4, 20);
      const thigh = new THREE.Mesh(thighGeom, limbMat);
      thigh.position.set(side * 0.42, -1.65, 0);
      skinGroup.add(thigh);

      // Calf
      const calfGeom = new THREE.CylinderGeometry(0.16, 0.12, 1.3, 20);
      const calf = new THREE.Mesh(calfGeom, limbMat);
      calf.position.set(side * 0.42, -3.0, 0);
      skinGroup.add(calf);
    });

    // --- 2. SKELETON LAYER ---
    const skeletonGroup = new THREE.Group();
    skeletonGroupRef.current = skeletonGroup;
    bodyGroup.add(skeletonGroup);

    const boneMaterial = new THREE.MeshStandardMaterial({
      color: 0xf1f5f9,
      roughness: 0.35,
      metalness: 0.1,
    });

    // Cranium
    const skull = new THREE.Mesh(new THREE.SphereGeometry(0.42, 24, 24), boneMaterial);
    skull.position.set(0, 2.55, 0.02);
    skull.scale.set(0.85, 1.05, 0.95);
    skeletonGroup.add(skull);

    // Spine
    for (let i = 0; i < 18; i++) {
      const vert = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.08, 12), boneMaterial);
      vert.position.set(0, 1.7 - i * 0.13, -0.12);
      skeletonGroup.add(vert);
    }

    // Rib cage
    for (let r = 0; r < 7; r++) {
      const ribRadius = 0.5 - Math.abs(r - 3) * 0.035;
      const ribGeom = new THREE.TorusGeometry(ribRadius, 0.024, 8, 24, Math.PI * 1.6);
      const rib = new THREE.Mesh(ribGeom, boneMaterial);
      rib.position.set(0, 1.4 - r * 0.16, -0.02);
      rib.rotation.x = Math.PI / 2 + 0.15;
      rib.rotation.z = Math.PI * 0.2;
      rib.scale.set(1.15, 0.75, 1);
      skeletonGroup.add(rib);
    }

    // Clavicles & Sternum
    const sternum = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.8, 0.04), boneMaterial);
    sternum.position.set(0, 0.95, 0.32);
    skeletonGroup.add(sternum);

    // Pelvic girdle
    const pelvicBrim = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.06, 12, 24), boneMaterial);
    pelvicBrim.position.set(0, -0.65, -0.05);
    pelvicBrim.rotation.x = Math.PI / 2.3;
    pelvicBrim.scale.set(1.1, 0.8, 1);
    skeletonGroup.add(pelvicBrim);

    // --- 3. MUSCLE LAYER ---
    const muscleGroup = new THREE.Group();
    muscleGroupRef.current = muscleGroup;
    muscleGroup.visible = false;
    bodyGroup.add(muscleGroup);

    const muscleMaterial = new THREE.MeshStandardMaterial({
      color: 0xbe123c,
      roughness: 0.6,
      metalness: 0.05,
    });

    // Pectorals
    [-1, 1].forEach((s) => {
      const pecs = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.28, 0.14), muscleMaterial);
      pecs.position.set(s * 0.28, 1.1, 0.3);
      pecs.rotation.z = s * -0.15;
      muscleGroup.add(pecs);

      // Deltoids
      const delt = new THREE.Mesh(new THREE.SphereGeometry(0.18, 16, 16), muscleMaterial);
      delt.position.set(s * 0.92, 1.35, 0.05);
      delt.scale.set(1, 1.4, 0.9);
      muscleGroup.add(delt);

      // Biceps
      const bic = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.09, 0.6, 12), muscleMaterial);
      bic.position.set(s * 1.05, 0.85, 0.06);
      muscleGroup.add(bic);

      // Quadriceps
      const quad = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.14, 1.1, 14), muscleMaterial);
      quad.position.set(s * 0.42, -1.65, 0.05);
      muscleGroup.add(quad);
    });

    // Abdominal rectus
    for (let a = 0; a < 3; a++) {
      [-1, 1].forEach((s) => {
        const absMesh = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.16, 0.08), muscleMaterial);
        absMesh.position.set(s * 0.12, 0.55 - a * 0.22, 0.28);
        muscleGroup.add(absMesh);
      });
    }

    // --- 4. INTERNAL ORGANS LAYER ---
    const organsGroup = new THREE.Group();
    organsGroupRef.current = organsGroup;
    bodyGroup.add(organsGroup);

    // Brain (SNC)
    const brainMat = new THREE.MeshStandardMaterial({ color: 0xf472b6, roughness: 0.4, bumpScale: 0.05 });
    const brain = new THREE.Mesh(new THREE.SphereGeometry(0.34, 24, 24), brainMat);
    brain.position.set(0, 2.6, 0.02);
    brain.scale.set(0.85, 0.95, 1.05);
    brain.userData = { id: 'nerveux', name: 'Encéphale & Cerveau' };
    organsGroup.add(brain);

    // Heart (Pulsing mesh)
    const heartMat = new THREE.MeshStandardMaterial({
      color: 0xdc2626,
      roughness: 0.3,
      emissive: 0x991b1b,
      emissiveIntensity: 0.25,
    });
    const heartGeom = new THREE.SphereGeometry(0.17, 24, 24);
    heartGeom.scale(0.9, 1.25, 0.85);
    const heart = new THREE.Mesh(heartGeom, heartMat);
    heart.position.set(-0.08, 0.95, 0.12);
    heart.rotation.z = 0.2;
    heart.userData = { id: 'cardiovasculaire', name: 'Cœur & Myocarde' };
    heartRef.current = heart;
    organsGroup.add(heart);

    // Lungs (Left & Right)
    const lungMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.75,
      roughness: 0.5,
    });

    const leftLung = new THREE.Mesh(new THREE.SphereGeometry(0.24, 20, 20), lungMat);
    leftLung.position.set(-0.34, 1.05, 0.05);
    leftLung.scale.set(0.8, 1.45, 0.7);
    leftLung.userData = { id: 'respiratoire', name: 'Poumon Gauche' };
    leftLungRef.current = leftLung;
    organsGroup.add(leftLung);

    const rightLung = new THREE.Mesh(new THREE.SphereGeometry(0.26, 20, 20), lungMat);
    rightLung.position.set(0.34, 1.05, 0.05);
    rightLung.scale.set(0.85, 1.5, 0.75);
    rightLung.userData = { id: 'respiratoire', name: 'Poumon Droit' };
    rightLungRef.current = rightLung;
    organsGroup.add(rightLung);

    // Stomach (Curved j-shape)
    const stomachMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.35 });
    const stomachCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.02, 0.6, 0.15),
      new THREE.Vector3(-0.18, 0.45, 0.18),
      new THREE.Vector3(-0.25, 0.25, 0.16),
      new THREE.Vector3(-0.08, 0.15, 0.14),
      new THREE.Vector3(0.08, 0.22, 0.12),
    ]);
    const stomachGeom = new THREE.TubeGeometry(stomachCurve, 20, 0.11, 16, false);
    const stomach = new THREE.Mesh(stomachGeom, stomachMat);
    stomach.userData = { id: 'digestif', name: 'Estomac (4 tuniques)' };
    organsGroup.add(stomach);

    // Liver (Right hypochondrium)
    const liverMat = new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.4 });
    const liver = new THREE.Mesh(new THREE.SphereGeometry(0.28, 20, 20), liverMat);
    liver.position.set(0.25, 0.45, 0.12);
    liver.scale.set(1.2, 0.7, 0.9);
    liver.rotation.z = -0.2;
    liver.userData = { id: 'digestif', name: 'Foie' };
    organsGroup.add(liver);

    // Small and Large Intestines
    const bowelMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.6 });
    const bowel = new THREE.Mesh(new THREE.TorusKnotGeometry(0.28, 0.065, 64, 16, 2, 3), bowelMat);
    bowel.position.set(0, -0.15, 0.14);
    bowel.scale.set(0.9, 0.8, 0.6);
    bowel.userData = { id: 'digestif', name: 'Intestin Grêle & Côlon' };
    organsGroup.add(bowel);

    // Kidneys & Urinary Bladder
    const kidneyMat = new THREE.MeshStandardMaterial({ color: 0x831843, roughness: 0.3 });
    [-1, 1].forEach((s) => {
      const kidney = new THREE.Mesh(new THREE.SphereGeometry(0.11, 16, 16), kidneyMat);
      kidney.position.set(s * 0.26, 0.3, -0.08);
      kidney.scale.set(0.7, 1.2, 0.8);
      kidney.userData = { id: 'urinaire', name: `Rein ${s > 0 ? 'Droit' : 'Gauche'}` };
      organsGroup.add(kidney);

      // Ureter
      const ureterMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const ureter = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.7, 8), ureterMat);
      ureter.position.set(s * 0.18, -0.15, -0.05);
      ureter.rotation.z = s * -0.2;
      organsGroup.add(ureter);
    });

    const bladderMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.2, transparent: true, opacity: 0.85 });
    const bladder = new THREE.Mesh(new THREE.SphereGeometry(0.13, 16, 16), bladderMat);
    bladder.position.set(0, -0.55, 0.06);
    bladder.userData = { id: 'urinaire', name: 'Vessie Urinaire' };
    organsGroup.add(bladder);

    // --- 5. CARDIOVASCULAR VESSELS LAYER & PARTICLES ---
    const vesselsGroup = new THREE.Group();
    vesselsGroupRef.current = vesselsGroup;
    bodyGroup.add(vesselsGroup);

    const arteryMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    const veinMat = new THREE.MeshBasicMaterial({ color: 0x2563eb });

    // Aorta & Main Artery Tree
    const aorta = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.025, 2.2, 12), arteryMat);
    aorta.position.set(-0.03, 0.2, 0.02);
    vesselsGroup.add(aorta);

    // Vena Cava
    const venaCava = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.025, 2.2, 12), veinMat);
    venaCava.position.set(0.04, 0.2, 0.02);
    vesselsGroup.add(venaCava);

    // Carotid and Jugular to head
    [-1, 1].forEach((s) => {
      const artNeck = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.8, 8), s > 0 ? arteryMat : veinMat);
      artNeck.position.set(s * 0.09, 1.8, 0.04);
      vesselsGroup.add(artNeck);

      // Iliac vessels to legs
      const artLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.014, 2.8, 8), arteryMat);
      artLeg.position.set(s * 0.35, -2.1, 0.03);
      vesselsGroup.add(artLeg);
    });

    // Blood cells flow particles
    const bloodParticleCount = 180;
    const bloodGeom = new THREE.BufferGeometry();
    const bloodPositions = new Float32Array(bloodParticleCount * 3);
    for (let b = 0; b < bloodParticleCount; b++) {
      const t = Math.random() * 5.0 - 2.5;
      bloodPositions[b * 3] = (Math.random() - 0.5) * 0.35;
      bloodPositions[b * 3 + 1] = t;
      bloodPositions[b * 3 + 2] = (Math.random() - 0.5) * 0.2;
    }
    bloodGeom.setAttribute('position', new THREE.BufferAttribute(bloodPositions, 3));
    const bloodParticleMat = new THREE.PointsMaterial({
      color: 0xff3b30,
      size: 0.05,
      transparent: true,
      opacity: 0.8,
    });
    const bloodParticles = new THREE.Points(bloodGeom, bloodParticleMat);
    bloodParticlesRef.current = bloodParticles;
    vesselsGroup.add(bloodParticles);

    // --- 6. NERVOUS SYSTEM LAYER ---
    const nervesGroup = new THREE.Group();
    nervesGroupRef.current = nervesGroup;
    bodyGroup.add(nervesGroup);

    const nerveLineMat = new THREE.LineBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.75 });
    // Spinal cord line
    const spinalPoints = [
      new THREE.Vector3(0, 2.3, -0.05),
      new THREE.Vector3(0, 1.5, -0.1),
      new THREE.Vector3(0, 0.5, -0.12),
      new THREE.Vector3(0, -0.4, -0.08),
    ];
    const spinalGeom = new THREE.BufferGeometry().setFromPoints(spinalPoints);
    const spinalCord = new THREE.Line(spinalGeom, new THREE.LineBasicMaterial({ color: 0x06b6d4, linewidth: 3 }));
    nervesGroup.add(spinalCord);

    // Peripheral nerve branches
    [-1, 1].forEach((s) => {
      // Brachial plexus to arms
      const armNervePoints = [
        new THREE.Vector3(0, 1.5, -0.08),
        new THREE.Vector3(s * 0.4, 1.3, 0),
        new THREE.Vector3(s * 0.9, 0.9, 0),
        new THREE.Vector3(s * 1.3, -0.1, 0),
      ];
      nervesGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(armNervePoints), nerveLineMat));

      // Sciatic nerve to legs
      const legNervePoints = [
        new THREE.Vector3(0, -0.4, -0.08),
        new THREE.Vector3(s * 0.3, -1.0, -0.05),
        new THREE.Vector3(s * 0.4, -2.2, -0.04),
        new THREE.Vector3(s * 0.4, -3.2, -0.02),
      ];
      nervesGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(legNervePoints), nerveLineMat));
    });

    // Raycasting for organ clicking
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const handlePointerDown = (event: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(organsGroup.children, true);
      if (intersects.length > 0) {
        const hit = intersects[0].object;
        if (hit.userData?.id) {
          onSelectOrgan?.(hit.userData.id);
        }
      }
    };

    const handlePointerMove = (event: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(organsGroup.children, true);
      if (intersects.length > 0 && intersects[0].object.userData?.name) {
        setHoveredPart(intersects[0].object.userData.name);
      } else {
        setHoveredPart(null);
      }
    };

    renderer.domElement.addEventListener('pointerdown', handlePointerDown);
    renderer.domElement.addEventListener('pointermove', handlePointerMove);

    // Orbit drag state
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging || !bodyGroup) return;
      const deltaX = e.clientX - prevMouseX;
      const deltaY = e.clientY - prevMouseY;
      bodyGroup.rotation.y += deltaX * 0.008;
      bodyGroup.rotation.x = Math.max(-0.6, Math.min(0.6, bodyGroup.rotation.x + deltaY * 0.005));
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      camera.position.z = Math.max(3.2, Math.min(10.5, camera.position.z + e.deltaY * 0.005));
    };

    container.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    container.addEventListener('wheel', onWheel, { passive: false });

    // ANIMATION LOOP
    let clock = new THREE.Clock();

    const animate = () => {
      reqIdRef.current = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Gentle auto-rotation when user is not dragging
      if (isPlaying && !isDragging && bodyGroup) {
        bodyGroup.rotation.y += 0.003;
      }

      // Heart pulse animation (72 bpm simulation)
      if (heartRef.current) {
        const beat = 1 + 0.1 * Math.sin(elapsedTime * 6) * Math.sin(elapsedTime * 3);
        heartRef.current.scale.set(0.9 * beat, 1.25 * beat, 0.85 * beat);
      }

      // Lungs breathing cycle (14 cycles per minute)
      const breath = 1 + 0.06 * Math.sin(elapsedTime * 1.5);
      if (leftLungRef.current && rightLungRef.current) {
        leftLungRef.current.scale.set(0.8 * breath, 1.45 * breath, 0.7 * breath);
        rightLungRef.current.scale.set(0.85 * breath, 1.5 * breath, 0.75 * breath);
      }

      // Blood particles circulating
      if (bloodParticlesRef.current) {
        const positions = bloodParticlesRef.current.geometry.attributes.position.array as Float32Array;
        for (let i = 1; i < positions.length; i += 3) {
          positions[i] -= 0.02;
          if (positions[i] < -3.2) {
            positions[i] = 2.4;
          }
        }
        bloodParticlesRef.current.geometry.attributes.position.needsUpdate = true;
      }

      renderer.render(scene, camera);
    };

    animate();

    // RESIZE OBSERVER
    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      if (reqIdRef.current) cancelAnimationFrame(reqIdRef.current);
      renderer.domElement.removeEventListener('pointerdown', handlePointerDown);
      renderer.domElement.removeEventListener('pointermove', handlePointerMove);
      container.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      container.removeEventListener('wheel', onWheel);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, []);

  // Sync layer visibility
  useEffect(() => {
    if (skinGroupRef.current) skinGroupRef.current.visible = layers.skin;
    if (skeletonGroupRef.current) skeletonGroupRef.current.visible = layers.skeleton;
    if (muscleGroupRef.current) muscleGroupRef.current.visible = layers.muscles;
    if (organsGroupRef.current) organsGroupRef.current.visible = layers.organs;
    if (vesselsGroupRef.current) vesselsGroupRef.current.visible = layers.vessels;
    if (nervesGroupRef.current) nervesGroupRef.current.visible = layers.nerves;
  }, [layers]);

  // Handle Preset Camera Positions
  const handlePreset = (preset: 'full' | 'head' | 'thorax' | 'abdomen' | 'urinary') => {
    setActivePreset(preset);
    if (!cameraRef.current || !groupBodyRef.current) return;
    const cam = cameraRef.current;
    const body = groupBodyRef.current;

    switch (preset) {
      case 'full':
        cam.position.set(0, 0, 7.5);
        body.position.set(0, 0, 0);
        break;
      case 'head':
        cam.position.set(0, 2.5, 3.8);
        body.position.set(0, -0.6, 0);
        break;
      case 'thorax':
        cam.position.set(0, 1.0, 4.2);
        body.position.set(0, 0, 0);
        break;
      case 'abdomen':
        cam.position.set(0, 0.1, 4.2);
        body.position.set(0, 0.4, 0);
        break;
      case 'urinary':
        cam.position.set(0, -0.4, 4.0);
        body.position.set(0, 0.8, 0);
        break;
    }
  };

  const handleZoom = (delta: number) => {
    if (!cameraRef.current) return;
    cameraRef.current.position.z = Math.max(3.2, Math.min(10.5, cameraRef.current.position.z + delta));
  };

  const handleResetRotation = () => {
    if (groupBodyRef.current) {
      groupBodyRef.current.rotation.set(0, 0, 0);
    }
    handlePreset('full');
  };

  return (
    <div className="relative w-full h-[620px] bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 rounded-2xl border border-slate-800/80 overflow-hidden shadow-2xl flex flex-col">
      {/* Top 3D Canvas HUD Info */}
      <div className="absolute top-4 left-4 z-10 flex flex-col gap-1 pointer-events-none">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-teal-400 animate-pulse" />
          <span className="text-xs font-semibold tracking-wider uppercase text-teal-400">
            Atlas Anatomique 3D Interactif
          </span>
        </div>
        <p className="text-xs text-slate-400 max-w-sm">
          Glissez pour faire pivoter à 360° · Molette pour zoomer · Cliquez sur un organe pour inspecter
        </p>
        {hoveredPart && (
          <div className="mt-2 inline-flex items-center gap-2 px-3 py-1 bg-slate-900/90 border border-teal-500/40 rounded-md text-xs text-teal-300 font-medium backdrop-blur-md shadow-lg">
            <Info className="w-3.5 h-3.5 text-teal-400" />
            <span>Survol : {hoveredPart}</span>
          </div>
        )}
      </div>

      {/* Preset Camera Views */}
      <div className="absolute top-4 right-4 z-10 flex items-center gap-1.5 bg-slate-900/85 backdrop-blur-md border border-slate-800 p-1.5 rounded-xl shadow-lg">
        {[
          { id: 'full', label: 'Corps Entier' },
          { id: 'head', label: 'Tête / SNC' },
          { id: 'thorax', label: 'Thorax' },
          { id: 'abdomen', label: 'Abdomen' },
          { id: 'urinary', label: 'Urinaire' },
        ].map((p) => (
          <button
            key={p.id}
            onClick={() => handlePreset(p.id as any)}
            className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              activePreset === p.id
                ? 'bg-teal-500 text-slate-950 font-semibold shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* 3D WebGL Canvas Container */}
      <div ref={containerRef} className="w-full flex-1 cursor-grab active:cursor-grabbing" />

      {/* Bottom Floating Control Deck: Layers & Playback */}
      <div className="absolute bottom-4 left-4 right-4 z-10 flex flex-wrap items-center justify-between gap-3 bg-slate-900/90 backdrop-blur-md border border-slate-800/90 px-4 py-2.5 rounded-xl shadow-xl">
        {/* Layer Switches */}
        <div className="flex items-center gap-2 flex-wrap text-xs">
          <span className="text-slate-400 flex items-center gap-1 mr-1">
            <Layers className="w-3.5 h-3.5 text-teal-400" />
            Calques :
          </span>
          {[
            { key: 'skin', label: 'Peau', active: layers.skin },
            { key: 'skeleton', label: 'Squelette', active: layers.skeleton },
            { key: 'muscles', label: 'Muscles', active: layers.muscles },
            { key: 'organs', label: 'Organes', active: layers.organs },
            { key: 'vessels', label: 'Vaisseaux', active: layers.vessels },
            { key: 'nerves', label: 'Nerfs', active: layers.nerves },
          ].map((layer) => (
            <button
              key={layer.key}
              onClick={() => setLayers((prev) => ({ ...prev, [layer.key]: !prev[layer.key as keyof typeof layers] }))}
              className={`px-2.5 py-1 rounded-md transition-all font-medium flex items-center gap-1 ${
                layer.active
                  ? 'bg-slate-800 border border-teal-500/50 text-teal-300'
                  : 'bg-slate-950/60 border border-slate-800 text-slate-500 hover:text-slate-300'
              }`}
            >
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  layer.active ? 'bg-teal-400' : 'bg-slate-600'
                }`}
              />
              {layer.label}
            </button>
          ))}
        </div>

        {/* Viewport Actions (Rotation, Play, Zoom) */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            title={isPlaying ? 'Pause la rotation' : 'Reprendre la rotation'}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
          >
            {isPlaying ? <Pause className="w-4 h-4 text-teal-400" /> : <Play className="w-4 h-4 text-slate-400" />}
          </button>
          <button
            onClick={() => handleZoom(-1.0)}
            title="Zoom avant"
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleZoom(1.0)}
            title="Zoom arrière"
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={handleResetRotation}
            title="Réinitialiser la vue"
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
