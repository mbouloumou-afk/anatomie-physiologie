import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { CELL_CYCLE_PHASES } from '../../data/courseData';
import { Play, Pause, RotateCcw, ChevronRight, ChevronLeft, Check, Sparkles } from 'lucide-react';

export const Mitosis3DScene: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const reqIdRef = useRef<number | null>(null);

  const [activeStep, setActiveStep] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'mitosis' | 'differentiation'>('mitosis');

  const steps = [
    {
      id: 'g1',
      title: 'Interphase - Phase G1',
      category: 'Interphase (90% du temps)',
      desc: 'Croissance de la cellule et préparation active à la réplication de l’ADN. Les chromosomes possèdent 1 seule chromatide.',
      tag: '1 chromatide par chromosome',
    },
    {
      id: 's',
      title: 'Interphase - Phase S (Synthèse)',
      category: 'Interphase',
      desc: 'Réplication de l’acide désoxyribonucléique (ADN). À la fin de la phase S, chaque chromosome possède 2 chromatides sœurs unies par le centromère.',
      tag: 'Réplication ADN terminée',
    },
    {
      id: 'g2',
      title: 'Interphase - Phase G2',
      category: 'Interphase',
      desc: 'Phase de croissance finale et préparation au début de la mitose. La cellule est prête à se diviser.',
      tag: 'Contrôle génomique & Centrosomes dupliqués',
    },
    {
      id: 'prophase',
      title: 'Mitose - 1. Prophase',
      category: 'Mitose',
      desc: 'Condensation de la chromatine en chromosomes visibles. Disparition du nucléole. Création du fuseau mitotique à partir des microtubules des centrosomes et fragmentation de l’enveloppe nucléaire.',
      tag: 'Condensation & Fuseau mitotique',
    },
    {
      id: 'metaphase',
      title: 'Mitose - 2. Métaphase',
      category: 'Mitose',
      desc: 'Alignement parfait des chromosomes au centre de la cellule, sur la plaque équatoriale, guidés par les fibres du fuseau mitotique.',
      tag: 'Plaque équatoriale centrale',
    },
    {
      id: 'anaphase',
      title: 'Mitose - 3. Anaphase',
      category: 'Mitose',
      desc: 'Séparation brutale des chromatides sœurs : les centromères se rompent et chaque chromatide est tractée vers un pôle opposé de la cellule.',
      tag: 'Séparation des chromatides sœurs',
    },
    {
      id: 'telophase',
      title: 'Mitose - 4. Télophase & Cytocinèse',
      category: 'Mitose',
      desc: 'Les chromatides séparées se décondensent. Disparition du fuseau mitotique. Reconstitution des enveloppes nucléaires autour de chaque groupe. Formation de deux cellules filles diploïdes identiques.',
      tag: '2 cellules filles identiques',
    },
  ];

  // 3D references to animate
  const chromosomesGroupRef = useRef<THREE.Group | null>(null);
  const spindleGroupRef = useRef<THREE.Group | null>(null);
  const cellMeshRef = useRef<THREE.Mesh | null>(null);
  const leftPoleRef = useRef<THREE.Mesh | null>(null);
  const rightPoleRef = useRef<THREE.Mesh | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 450;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0, 7.5);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lights
    scene.add(new THREE.AmbientLight(0xffffff, 0.5));
    const dLight = new THREE.DirectionalLight(0x38bdf8, 1.2);
    dLight.position.set(5, 6, 6);
    scene.add(dLight);

    const backLight = new THREE.DirectionalLight(0xec4899, 0.8);
    backLight.position.set(-5, -5, -4);
    scene.add(backLight);

    const root = new THREE.Group();
    scene.add(root);

    // Outer Cell membrane (Pinching in telophase)
    const cellGeom = new THREE.SphereGeometry(2.4, 32, 32);
    const cellMat = new THREE.MeshPhysicalMaterial({
      color: 0x0284c7,
      transparent: true,
      opacity: 0.18,
      roughness: 0.2,
      transmission: 0.6,
      side: THREE.DoubleSide,
    });
    const cellMesh = new THREE.Mesh(cellGeom, cellMat);
    cellMeshRef.current = cellMesh;
    root.add(cellMesh);

    // Centrosomes Poles (Left & Right)
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x0284c7, emissiveIntensity: 0.5 });
    const leftPole = new THREE.Mesh(new THREE.SphereGeometry(0.18, 16, 16), poleMat);
    leftPole.position.set(-2.0, 0, 0);
    leftPoleRef.current = leftPole;
    root.add(leftPole);

    const rightPole = new THREE.Mesh(new THREE.SphereGeometry(0.18, 16, 16), poleMat);
    rightPole.position.set(2.0, 0, 0);
    rightPoleRef.current = rightPole;
    root.add(rightPole);

    // Mitotic Spindle Fibers Group
    const spindleGroup = new THREE.Group();
    spindleGroupRef.current = spindleGroup;
    root.add(spindleGroup);

    // Spindle lines connecting poles to center
    const spindleMat = new THREE.LineBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.45 });
    for (let s = -5; s <= 5; s++) {
      const lineGeom = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(-2.0, 0, 0),
        new THREE.Vector3(0, s * 0.25, Math.sin(s) * 0.3),
        new THREE.Vector3(2.0, 0, 0),
      ]);
      spindleGroup.add(new THREE.Line(lineGeom, spindleMat));
    }

    // Chromosomes Group
    const chromoGroup = new THREE.Group();
    chromosomesGroupRef.current = chromoGroup;
    root.add(chromoGroup);

    // 4 representative chromosome pairs (X shapes)
    const chromoMat1 = new THREE.MeshStandardMaterial({ color: 0xec4899, roughness: 0.3 });
    const chromoMat2 = new THREE.MeshStandardMaterial({ color: 0x8b5cf6, roughness: 0.3 });

    for (let c = 0; c < 4; c++) {
      const singleChromo = new THREE.Group();
      singleChromo.name = `chromo_${c}`;

      // Left Chromatid
      const leftArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.6, 8, 12), c % 2 === 0 ? chromoMat1 : chromoMat2);
      leftArm.name = 'arm_left';
      leftArm.rotation.z = 0.35;
      singleChromo.add(leftArm);

      // Right Chromatid
      const rightArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.6, 8, 12), c % 2 === 0 ? chromoMat1 : chromoMat2);
      rightArm.name = 'arm_right';
      rightArm.rotation.z = -0.35;
      singleChromo.add(rightArm);

      // Centromere sphere
      const centromere = new THREE.Mesh(new THREE.SphereGeometry(0.09, 12, 12), new THREE.MeshStandardMaterial({ color: 0xfacc15 }));
      centromere.name = 'centromere';
      singleChromo.add(centromere);

      singleChromo.position.set(0, (c - 1.5) * 0.65, 0);
      chromoGroup.add(singleChromo);
    }

    // Animation Loop
    let clock = new THREE.Clock();

    const animate = () => {
      reqIdRef.current = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // Slow 3D rotation
      root.rotation.y = Math.sin(elapsed * 0.3) * 0.2;

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const nw = container.clientWidth;
      const nh = container.clientHeight;
      camera.aspect = nw / nh;
      camera.updateProjectionMatrix();
      renderer.setSize(nw, nh);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      if (reqIdRef.current) cancelAnimationFrame(reqIdRef.current);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, []);

  // Update 3D Stage according to activeStep (Interphase -> Mitose steps)
  useEffect(() => {
    if (!chromosomesGroupRef.current || !spindleGroupRef.current || !cellMeshRef.current) return;
    const chromoGroup = chromosomesGroupRef.current;
    const spindle = spindleGroupRef.current;
    const cell = cellMeshRef.current;

    // Step 0: G1 (Diffuse, single chromatid, no spindle)
    // Step 1: S (Replication, 2 chromatides)
    // Step 2: G2 (Ready, centrosomes doubled)
    // Step 3: Prophase (Condensation, spindle appears, envelope starts breaking)
    // Step 4: Metaphase (Equatorial plate alignment)
    // Step 5: Anaphase (Separation of sister chromatids to poles)
    // Step 6: Telophase (Cell pinching, reconstitution)

    if (activeStep <= 2) {
      // Interphase: spindle hidden, chromosomes less condensed
      spindle.visible = false;
      cell.scale.set(1, 1, 1);
      chromoGroup.children.forEach((c, idx) => {
        const leftArm = c.getObjectByName('arm_left');
        const rightArm = c.getObjectByName('arm_right');
        if (leftArm && rightArm) {
          leftArm.position.set(0, 0, 0);
          // in G1, second chromatid is invisible or single
          rightArm.visible = activeStep >= 1;
        }
        c.position.set((idx % 2 === 0 ? -0.4 : 0.4), (idx - 1.5) * 0.5, 0);
        c.rotation.z = idx * 0.4;
      });
    } else if (activeStep === 3) {
      // Prophase: spindle emerges, chromosomes condensed
      spindle.visible = true;
      spindle.children.forEach((l) => {
        const line = l as THREE.Line;
        (line.material as THREE.LineBasicMaterial).opacity = 0.25;
      });
      cell.scale.set(1, 1, 1);
      chromoGroup.children.forEach((c, idx) => {
        const leftArm = c.getObjectByName('arm_left');
        const rightArm = c.getObjectByName('arm_right');
        if (leftArm && rightArm) {
          leftArm.position.set(0, 0, 0);
          rightArm.position.set(0, 0, 0);
          rightArm.visible = true;
        }
        c.position.set((idx % 2 === 0 ? -0.2 : 0.2), (idx - 1.5) * 0.55, 0);
        c.rotation.z = idx * 0.2;
      });
    } else if (activeStep === 4) {
      // Metaphase: Perfect equatorial alignment at X: 0
      spindle.visible = true;
      spindle.children.forEach((l) => {
        const line = l as THREE.Line;
        (line.material as THREE.LineBasicMaterial).opacity = 0.65;
      });
      cell.scale.set(1, 1, 1);
      chromoGroup.children.forEach((c, idx) => {
        const leftArm = c.getObjectByName('arm_left');
        const rightArm = c.getObjectByName('arm_right');
        if (leftArm && rightArm) {
          leftArm.position.set(0, 0, 0);
          rightArm.position.set(0, 0, 0);
          rightArm.visible = true;
        }
        c.position.set(0, (idx - 1.5) * 0.65, 0);
        c.rotation.z = 0;
      });
    } else if (activeStep === 5) {
      // Anaphase: Sister chromatids pulled towards opposite poles (-1.3 and +1.3)
      spindle.visible = true;
      cell.scale.set(1.2, 0.9, 0.9);
      chromoGroup.children.forEach((c, idx) => {
        const leftArm = c.getObjectByName('arm_left');
        const rightArm = c.getObjectByName('arm_right');
        if (leftArm && rightArm) {
          leftArm.position.set(-1.1, 0, 0);
          rightArm.position.set(1.1, 0, 0);
          rightArm.visible = true;
        }
        c.position.set(0, (idx - 1.5) * 0.5, 0);
      });
    } else if (activeStep === 6) {
      // Telophase & Cytocinese: Cell pinches in center, 2 daughter clusters
      spindle.visible = false;
      cell.scale.set(1.4, 0.8, 0.75);
      chromoGroup.children.forEach((c, idx) => {
        const leftArm = c.getObjectByName('arm_left');
        const rightArm = c.getObjectByName('arm_right');
        if (leftArm && rightArm) {
          leftArm.position.set(-1.3, (idx % 2 === 0 ? 0.2 : -0.2), 0);
          rightArm.position.set(1.3, (idx % 2 === 0 ? 0.2 : -0.2), 0);
          rightArm.visible = true;
        }
      });
    }
  }, [activeStep]);

  // Autoplay progression
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setActiveStep((prev) => (prev + 1) % steps.length);
    }, 2800);
    return () => clearInterval(interval);
  }, [isPlaying, steps.length]);

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col gap-6">
      {/* Top Header & View Mode Switcher */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <span className="text-xs uppercase tracking-wider font-semibold text-rose-400">
            Diapositives 19 à 22 · Cycle et Différenciation Cellulaire
          </span>
          <h3 className="text-2xl font-bold text-white mt-1">
            Simulateur 3D : Mitose & Différenciation
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Objectifs : Réparer les tissus, remplacer les cellules mortes, reproduction et croissance.
          </p>
        </div>

        {/* View Switcher: Mitosis vs Cellular Differentiation */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800">
          <button
            onClick={() => setViewMode('mitosis')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              viewMode === 'mitosis'
                ? 'bg-rose-500 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Mitose 3D & Interphase
          </button>
          <button
            onClick={() => setViewMode('differentiation')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              viewMode === 'differentiation'
                ? 'bg-rose-500 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Arbre de Différenciation
          </button>
        </div>
      </div>

      {viewMode === 'mitosis' ? (
        <>
          {/* Step Timeline Indicator */}
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-1.5">
            {steps.map((st, index) => (
              <button
                key={st.id}
                onClick={() => {
                  setActiveStep(index);
                  setIsPlaying(false);
                }}
                className={`p-2 rounded-xl text-left transition-all border ${
                  activeStep === index
                    ? 'bg-rose-950/60 border-rose-500 text-rose-200 shadow-md'
                    : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <div className="text-[10px] uppercase font-bold text-slate-500">
                  Étape {index + 1}
                </div>
                <div className="text-xs font-semibold truncate mt-0.5">{st.title.split(' - ')[1] || st.title}</div>
              </button>
            ))}
          </div>

          {/* 3D Canvas Viewport */}
          <div className="relative w-full h-[400px] bg-slate-950 rounded-xl border border-slate-800/80 overflow-hidden">
            {/* Step HUD Overlay */}
            <div className="absolute top-3 left-4 z-10 bg-slate-900/90 border border-slate-800 px-3.5 py-2 rounded-xl text-xs backdrop-blur-md max-w-md">
              <span className="text-[10px] uppercase font-bold tracking-wider text-rose-400">
                {steps[activeStep].category}
              </span>
              <h4 className="text-sm font-bold text-white mt-0.5">{steps[activeStep].title}</h4>
              <p className="text-slate-300 mt-1 text-[11px] leading-relaxed">{steps[activeStep].desc}</p>
              <div className="mt-2 inline-flex items-center gap-1.5 px-2 py-0.5 bg-rose-500/20 text-rose-300 rounded text-[10px] font-semibold">
                <Check className="w-3 h-3" />
                {steps[activeStep].tag}
              </div>
            </div>

            {/* Canvas */}
            <div ref={containerRef} className="w-full h-full" />

            {/* Playback Controls */}
            <div className="absolute bottom-3 right-4 z-10 flex items-center gap-2 bg-slate-900/90 backdrop-blur-md p-1.5 rounded-xl border border-slate-800">
              <button
                onClick={() => setActiveStep((prev) => (prev > 0 ? prev - 1 : steps.length - 1))}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200"
                title="Étape précédente"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="px-3 py-1.5 rounded-lg bg-rose-500 hover:bg-rose-600 text-white font-semibold text-xs flex items-center gap-1.5"
              >
                {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>{isPlaying ? 'Pause' : 'Lecture Auto'}</span>
              </button>
              <button
                onClick={() => setActiveStep((prev) => (prev + 1) % steps.length)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200"
                title="Étape suivante"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  setActiveStep(0);
                  setIsPlaying(false);
                }}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200"
                title="Recommencer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        </>
      ) : (
        /* Cellular Differentiation Tree from slide 22 */
        <div className="space-y-4">
          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-xl text-xs text-slate-300 leading-relaxed">
            <h4 className="text-sm font-bold text-white mb-1">
              De la cellule œuf aux 100 000 milliards de cellules spécialisées
            </h4>
            <p>
              Toutes les cellules du corps humain descendent d'une cellule œuf unique (zygote). Au cours du
              développement embryonnaire, les cellules subissent une restriction progressive de leur potentiel
              de différenciation pour acquérir des fonctions ultra-spécifiques.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
            {[
              {
                stage: '1. Totipotentes',
                cells: 'Cellule œuf & Embryon J1-J4',
                potency: 'Totale (100%)',
                desc: 'Les toutes premières cellules. Capables de donner naissance à un organisme entier complet ainsi qu’aux annexes embryonnaires (placenta).',
                color: 'border-amber-500/60 bg-amber-950/20 text-amber-200',
              },
              {
                stage: '2. Pluripotentes',
                cells: 'Blastocyste (Embryon J5)',
                potency: 'Multiplication à volonté',
                desc: 'Peuvent se multiplier à l’infini et donner tous les types cellulaires des 3 feuillets embryonnaires, mais pas le placenta seul.',
                color: 'border-cyan-500/60 bg-cyan-950/20 text-cyan-200',
              },
              {
                stage: '3. Multipotentes',
                cells: 'Feuillets embryonnaires',
                potency: 'Spécialisation lignée',
                desc: 'Cellules spécialisées dans un genre tissulaire précis : Ectoderme (peau, système nerveux), Mésoderme (sang, squelette, reins), Endoderme (tube digestif, appareil respiratoire).',
                color: 'border-indigo-500/60 bg-indigo-950/20 text-indigo-200',
              },
              {
                stage: '4. Unipotentes',
                cells: 'Cellules souches tissulaires',
                potency: 'Destin scellé',
                desc: 'Leur destin est définitivement tracé. Elles ne peuvent renouveler qu’un seul et unique type cellulaire spécifique (ex: cellules souches basales de la peau).',
                color: 'border-emerald-500/60 bg-emerald-950/20 text-emerald-200',
              },
              {
                stage: '5. Spécialisées Matures',
                cells: 'Cellules adultes fonctionnelles',
                potency: 'Fonction spécifique',
                desc: 'Neurone (influx nerveux), Myocyte (contraction), Hématie (transport O2), Ostéocyte (matrice osseuse), Cellule pancréatique (insuline).',
                color: 'border-rose-500/60 bg-rose-950/20 text-rose-200',
              },
            ].map((level, i) => (
              <div key={i} className={`p-4 rounded-xl border flex flex-col justify-between ${level.color}`}>
                <div>
                  <span className="text-[10px] uppercase font-bold tracking-wider opacity-75">{level.cells}</span>
                  <h5 className="text-sm font-bold text-white mt-1">{level.stage}</h5>
                  <p className="mt-2 text-slate-300 leading-relaxed text-[11px]">{level.desc}</p>
                </div>
                <div className="mt-4 pt-2 border-t border-white/10 text-[10px] font-semibold flex items-center justify-between">
                  <span>Potentiel :</span>
                  <span className="font-bold">{level.potency}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
