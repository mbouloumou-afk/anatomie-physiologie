import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { MEMBRANE_TRANSPORTS } from '../../data/courseData';
import { Play, Pause, RotateCcw, Zap, ArrowDown, ArrowUp, RefreshCw } from 'lucide-react';

export const Transport3DScene: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const reqIdRef = useRef<number | null>(null);

  const [activeMode, setActiveMode] = useState<'passive_simple' | 'passive_facilitee' | 'active_pump' | 'vesicular'>(
    'passive_facilitee'
  );
  const [isRunning, setIsRunning] = useState(true);
  const [gradientDelta, setGradientDelta] = useState(80); // Extracellular vs Intracellular
  const [atpCount, setAtpCount] = useState(12);

  // References for animated elements
  const particlesGroupRef = useRef<THREE.Group | null>(null);
  const pumpGateRef = useRef<THREE.Mesh | null>(null);
  const vesicleMeshRef = useRef<THREE.Mesh | null>(null);
  const atpMeshRef = useRef<THREE.Mesh | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0, 8);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // LIGHTING
    scene.add(new THREE.AmbientLight(0xffffff, 0.5));
    const dirLight = new THREE.DirectionalLight(0x38bdf8, 1.2);
    dirLight.position.set(4, 6, 5);
    scene.add(dirLight);

    const backLight = new THREE.DirectionalLight(0xf59e0b, 0.8);
    backLight.position.set(-4, -6, -4);
    scene.add(backLight);

    // ROOT SCENE GROUP
    const root = new THREE.Group();
    scene.add(root);

    // --- 1. BICOUCHE PHOSPHOLIPIDIQUE (Phospholipid Bilayer) ---
    const bilayerGroup = new THREE.Group();
    root.add(bilayerGroup);

    const headMatUpper = new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.2 });
    const headMatLower = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.2 });
    const tailMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });

    const headGeom = new THREE.SphereGeometry(0.12, 12, 12);
    const tailGeom = new THREE.CylinderGeometry(0.015, 0.015, 0.45, 6);

    // Grid of lipids
    const cols = 22;
    const rows = 6;
    for (let c = -cols / 2; c < cols / 2; c++) {
      for (let r = -rows / 2; r < rows / 2; r++) {
        // Leave space in center for protein pump/channel
        if (Math.abs(c) < 3) continue;

        const x = c * 0.28;
        const z = r * 0.28;

        // Top Layer (Extracellular facing)
        const upperHead = new THREE.Mesh(headGeom, headMatUpper);
        upperHead.position.set(x, 0.5, z);
        bilayerGroup.add(upperHead);

        const upperTail = new THREE.Mesh(tailGeom, tailMat);
        upperTail.position.set(x, 0.25, z);
        bilayerGroup.add(upperTail);

        // Bottom Layer (Intracellular cytosol facing)
        const lowerHead = new THREE.Mesh(headGeom, headMatLower);
        lowerHead.position.set(x, -0.5, z);
        bilayerGroup.add(lowerHead);

        const lowerTail = new THREE.Mesh(tailGeom, tailMat);
        lowerTail.position.set(x, -0.25, z);
        bilayerGroup.add(lowerTail);
      }
    }

    // --- 2. TRANSMEMBRANE PROTEIN (Canal ionique / Perméase / Pompe) ---
    const proteinGroup = new THREE.Group();
    root.add(proteinGroup);

    const proteinMat = new THREE.MeshStandardMaterial({
      color: 0x8b5cf6,
      roughness: 0.35,
      metalness: 0.1,
    });

    // Left barrel subunit
    const leftSubunit = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 1.4, 20), proteinMat);
    leftSubunit.position.set(-0.45, 0, 0);
    proteinGroup.add(leftSubunit);

    // Right barrel subunit
    const rightSubunit = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 1.4, 20), proteinMat);
    rightSubunit.position.set(0.45, 0, 0);
    proteinGroup.add(rightSubunit);

    // Central channel gate (moves during active/facilitated transport)
    const gateGeom = new THREE.SphereGeometry(0.24, 16, 16);
    const gateMat = new THREE.MeshStandardMaterial({ color: 0xec4899 });
    const gateMesh = new THREE.Mesh(gateGeom, gateMat);
    gateMesh.position.set(0, 0, 0);
    pumpGateRef.current = gateMesh;
    proteinGroup.add(gateMesh);

    // ATP molecule indicator for Active Transport
    const atpGroup = new THREE.Group();
    const atpGeom = new THREE.DodecahedronGeometry(0.18);
    const atpMat = new THREE.MeshStandardMaterial({
      color: 0xfacc15,
      emissive: 0xeab308,
      emissiveIntensity: 0.6,
    });
    const atpMesh = new THREE.Mesh(atpGeom, atpMat);
    atpMesh.position.set(0.6, -1.0, 0.4);
    atpMeshRef.current = atpMesh;
    atpGroup.add(atpMesh);
    root.add(atpGroup);

    // --- 3. VESICULE POUR ENDOCYTOSE / EXOCYTOSE ---
    const vesGeom = new THREE.SphereGeometry(0.6, 24, 24);
    const vesMat = new THREE.MeshStandardMaterial({
      color: 0x10b981,
      transparent: true,
      opacity: 0.7,
      wireframe: false,
    });
    const vesicleMesh = new THREE.Mesh(vesGeom, vesMat);
    vesicleMesh.position.set(0, -1.8, 0);
    vesicleMesh.scale.set(0.01, 0.01, 0.01);
    vesicleMeshRef.current = vesicleMesh;
    root.add(vesicleMesh);

    // --- 4. SOLUTE PARTICLES ---
    const particlesGroup = new THREE.Group();
    particlesGroupRef.current = particlesGroup;
    root.add(particlesGroup);

    const pCount = 90;
    const pGeom = new THREE.SphereGeometry(0.065, 8, 8);
    const pMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.2 });

    for (let p = 0; p < pCount; p++) {
      const pm = new THREE.Mesh(pGeom, pMat);
      // Spawn higher up in extracellular compartment
      const isExtra = Math.random() < 0.7;
      pm.position.set(
        (Math.random() - 0.5) * 5.5,
        isExtra ? 1.0 + Math.random() * 2.2 : -1.0 - Math.random() * 2.0,
        (Math.random() - 0.5) * 1.5
      );
      pm.userData = {
        speed: 0.015 + Math.random() * 0.02,
        direction: -1, // Moving down towards cytoplasm
      };
      particlesGroup.add(pm);
    }

    // Animation Loop
    let clock = new THREE.Clock();

    const animate = () => {
      reqIdRef.current = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      if (isRunning) {
        // Subtle tilt
        root.rotation.y = Math.sin(elapsed * 0.4) * 0.15;

        // Animate particles according to transport mode
        if (particlesGroupRef.current) {
          particlesGroupRef.current.children.forEach((p, idx) => {
            const mesh = p as THREE.Mesh;
            const data = mesh.userData;

            if (activeMode === 'passive_simple') {
              // Direct diffusion across lipid bilayer
              mesh.position.y -= data.speed;
              if (mesh.position.y < -2.8) {
                mesh.position.y = 2.8;
                mesh.position.x = (Math.random() - 0.5) * 5.0;
              }
            } else if (activeMode === 'passive_facilitee') {
              // Steered towards central channel (x: 0)
              if (mesh.position.y > 0.5) {
                mesh.position.x += (0 - mesh.position.x) * 0.03;
              }
              mesh.position.y -= data.speed * 1.5;
              if (mesh.position.y < -2.8) {
                mesh.position.y = 2.8;
                mesh.position.x = (Math.random() - 0.5) * 4.5;
              }
            } else if (activeMode === 'active_pump') {
              // Pumping AGAINST gradient (from down to up!)
              mesh.position.y += data.speed * 1.3;
              if (mesh.position.y < 0.2 && mesh.position.y > -1.0) {
                mesh.position.x += (0 - mesh.position.x) * 0.05;
              }
              if (mesh.position.y > 2.8) {
                mesh.position.y = -2.6;
                mesh.position.x = (Math.random() - 0.5) * 4.0;
              }
            }
          });
        }

        // Pump Gate motion
        if (pumpGateRef.current) {
          if (activeMode === 'active_pump' || activeMode === 'passive_facilitee') {
            pumpGateRef.current.scale.x = 0.5 + 0.4 * Math.sin(elapsed * 4);
            pumpGateRef.current.position.y = 0.2 * Math.sin(elapsed * 3);
          } else {
            pumpGateRef.current.scale.set(1, 1, 1);
          }
        }

        // ATP pulsation in active transport
        if (atpMeshRef.current) {
          if (activeMode === 'active_pump') {
            atpMeshRef.current.visible = true;
            const atpPulse = 1 + 0.2 * Math.sin(elapsed * 6);
            atpMeshRef.current.scale.set(atpPulse, atpPulse, atpPulse);
            atpMeshRef.current.rotation.y += 0.03;
          } else {
            atpMeshRef.current.visible = false;
          }
        }

        // Vesicular Transport: Invagination & fusion cycle
        if (vesicleMeshRef.current) {
          if (activeMode === 'vesicular') {
            vesicleMeshRef.current.visible = true;
            const cycle = (elapsed * 0.6) % 3; // 0 to 3 seconds cycle
            if (cycle < 1.5) {
              // Endocytose: starts near membrane (y: 0.4), grows and moves down into cytoplasm (y: -2.0)
              const t = cycle / 1.5;
              vesicleMeshRef.current.position.y = 0.4 - t * 2.2;
              const scale = Math.sin(t * Math.PI) * 0.8;
              vesicleMeshRef.current.scale.set(scale, scale, scale);
            } else {
              // Exocytose: moves from deep (y: -2.2) up to membrane and releases
              const t = (cycle - 1.5) / 1.5;
              vesicleMeshRef.current.position.y = -2.2 + t * 2.4;
              const scale = (1 - t * 0.8) * 0.7;
              vesicleMeshRef.current.scale.set(scale, scale, scale);
            }
          } else {
            vesicleMeshRef.current.visible = false;
          }
        }
      }

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const nw = container.clientWidth;
      const nh = container.clientHeight;
      camera.aspect = nw / nh;
      camera.updateProjectionMatrix();
      renderer.setSize(nw, nh);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      if (reqIdRef.current) cancelAnimationFrame(reqIdRef.current);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, [activeMode, isRunning]);

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col gap-6">
      {/* Top Header & Mode Switcher */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <span className="text-xs uppercase tracking-wider font-semibold text-teal-400">
            Diapositive 11 · Physiologie Cellulaire
          </span>
          <h3 className="text-2xl font-bold text-white mt-1">
            Simulateur 3D des Transports Membranaires
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Bicouche phospholipidique, canaux ioniques, perméases et pompes à ATP.
          </p>
        </div>

        {/* 4 Interactive Transport Modes */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 flex-wrap">
          {[
            { id: 'passive_simple', label: '1. Diffusion Simple (Osmose)' },
            { id: 'passive_facilitee', label: '2. Diffusion Facilitée (Canal)' },
            { id: 'active_pump', label: '3. Transport Actif (Pompe ATP)' },
            { id: 'vesicular', label: '4. Endocytose / Exocytose' },
          ].map((mode) => (
            <button
              key={mode.id}
              onClick={() => setActiveMode(mode.id as any)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap ${
                activeMode === mode.id
                  ? 'bg-teal-500 text-slate-950 font-bold shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              {mode.label}
            </button>
          ))}
        </div>
      </div>

      {/* 3D Simulation Canvas */}
      <div className="relative w-full h-[400px] bg-slate-950 rounded-xl border border-slate-800/80 overflow-hidden">
        {/* Extracellular / Intracellular Zone Annotations */}
        <div className="absolute top-3 left-4 z-10 bg-sky-950/80 border border-sky-800/60 px-3 py-1.5 rounded-lg text-xs font-semibold text-sky-300 backdrop-blur-md flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-sky-400" />
          Milieu Extracellulaire [Gradient +]
        </div>

        <div className="absolute bottom-3 left-4 z-10 bg-indigo-950/80 border border-indigo-800/60 px-3 py-1.5 rounded-lg text-xs font-semibold text-indigo-300 backdrop-blur-md flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-indigo-400" />
          Milieu Intracellulaire (Cytosol) [Gradient -]
        </div>

        {/* Canvas DOM container */}
        <div ref={containerRef} className="w-full h-full" />

        {/* Play/Pause control */}
        <div className="absolute top-3 right-4 z-10 flex items-center gap-2 bg-slate-900/80 backdrop-blur-md p-1.5 rounded-lg border border-slate-800">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className="p-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200"
          >
            {isRunning ? <Pause className="w-4 h-4 text-teal-400" /> : <Play className="w-4 h-4 text-slate-400" />}
          </button>
        </div>
      </div>

      {/* Pedagogical Explanation Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 flex flex-col gap-1.5">
          <span className="text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
            Dépense Énergétique (ATP)
          </span>
          <div className="flex items-center gap-2 mt-1">
            <Zap className={`w-4 h-4 ${activeMode === 'active_pump' ? 'text-amber-400' : 'text-slate-600'}`} />
            <span className={`font-bold text-sm ${activeMode === 'active_pump' ? 'text-amber-300' : 'text-slate-300'}`}>
              {activeMode === 'active_pump'
                ? 'Nécessite de l’ATP (Pompes Na+, Ca++, H+)'
                : activeMode === 'vesicular'
                ? 'Consommation d’énergie et cytosquelette'
                : 'Aucune énergie requise (0 ATP)'}
            </span>
          </div>
          <p className="text-slate-500 mt-1">
            {activeMode === 'active_pump'
              ? 'Hydrolyse de l’ATP en ADP + Phosphate inorganique pour vaincre le gradient.'
              : 'Déplacement spontané selon les lois physiques thermodynamiques de diffusion.'}
          </p>
        </div>

        <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 flex flex-col gap-1.5">
          <span className="text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
            Sens du Déplacement
          </span>
          <div className="flex items-center gap-2 mt-1">
            {activeMode === 'active_pump' ? (
              <ArrowUp className="w-4 h-4 text-rose-400" />
            ) : (
              <ArrowDown className="w-4 h-4 text-teal-400" />
            )}
            <span className="font-bold text-sm text-slate-200">
              {activeMode === 'active_pump'
                ? 'Contre le gradient (du - vers le +)'
                : 'Selon le gradient (du + vers le -)'}
            </span>
          </div>
          <p className="text-slate-500 mt-1">
            {activeMode === 'active_pump'
              ? 'Concentration d’ions à l’intérieur ou l’extérieur de la cellule.'
              : 'Équilibre les concentrations de part et d’autre de la membrane.'}
          </p>
        </div>

        <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 flex flex-col gap-1.5">
          <span className="text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
            Structures Impliquées
          </span>
          <div className="flex items-center gap-2 mt-1">
            <RefreshCw className="w-4 h-4 text-cyan-400" />
            <span className="font-bold text-sm text-cyan-300">
              {activeMode === 'passive_simple' && 'Bicouche phospholipidique pure (gaz, eau)'}
              {activeMode === 'passive_facilitee' && 'Canal ionique ou Perméase de transport'}
              {activeMode === 'active_pump' && 'Pompe transmembranaire ATP-dépendante'}
              {activeMode === 'vesicular' && 'Invagination membranaire & Vésicules'}
            </span>
          </div>
          <p className="text-slate-500 mt-1">
            {activeMode === 'vesicular'
              ? 'Phagocytose (solides) / Pinocytose (liquides) / Exocytose (sécrétion).'
              : 'Perméabilité sélective garantissant l’intégrité du milieu intracellulaire.'}
          </p>
        </div>
      </div>
    </div>
  );
};
