import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { TISSUES, STOMACH_ORGAN_EXAMPLE, IMAGES } from '../../data/courseData';
import { Layers, Eye, CheckCircle2, ChevronRight, Activity } from 'lucide-react';

export const TissueOrgan3DScene: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const reqIdRef = useRef<number | null>(null);

  const [activeTab, setActiveTab] = useState<'organ_stomach' | 'tissues'>('organ_stomach');
  const [selectedTissue, setSelectedTissue] = useState<string>('epithelial');
  const [exploded, setExploded] = useState<boolean>(true);

  // References to stomach layer meshes
  const layerMeshesRef = useRef<THREE.Mesh[]>([]);

  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 450;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0, 6.2);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lights
    scene.add(new THREE.AmbientLight(0xffffff, 0.5));
    const dirLight = new THREE.DirectionalLight(0x38bdf8, 1.2);
    dirLight.position.set(5, 6, 6);
    scene.add(dirLight);

    const backLight = new THREE.DirectionalLight(0xf59e0b, 0.6);
    backLight.position.set(-5, -4, -4);
    scene.add(backLight);

    const root = new THREE.Group();
    scene.add(root);

    layerMeshesRef.current = [];

    // --- 3D EXPLODED STOMACH LAYERS ---
    const layerColors = [
      0xf43f5e, // Muqueuse Épithéliale (Rose)
      0xfacc15, // Sous-muqueuse Conjonctive (Jaune)
      0xef4444, // Musculeuse Lisse (Rouge muscle)
      0x06b6d4, // Plexus Nerveux & Séreuse (Cyan)
    ];

    // Build 4 concentric curved stomach arches
    for (let i = 0; i < 4; i++) {
      const radius = 1.1 + i * 0.15;
      const geom = new THREE.TorusGeometry(radius, 0.22 - i * 0.02, 16, 32, Math.PI * 1.1);
      const mat = new THREE.MeshStandardMaterial({
        color: layerColors[i],
        roughness: 0.35,
        metalness: 0.1,
        side: THREE.DoubleSide,
      });
      const mesh = new THREE.Mesh(geom, mat);
      mesh.rotation.z = -Math.PI * 0.55;
      mesh.position.set(i * 0.55 - 0.8, 0, 0);
      mesh.userData = { defaultX: i * 0.55 - 0.8, collapsedX: 0 };
      layerMeshesRef.current.push(mesh);
      root.add(mesh);
    }

    // Animation Loop
    let clock = new THREE.Clock();
    const animate = () => {
      reqIdRef.current = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // Gentle rotation
      root.rotation.y = Math.sin(elapsed * 0.4) * 0.25;
      root.rotation.x = Math.sin(elapsed * 0.2) * 0.1;

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const nw = container.clientWidth;
      const nh = container.clientHeight;
      camera.aspect = nw / nh;
      camera.updateProjectionMatrix();
      renderer.setSize(nw, nh);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      if (reqIdRef.current) cancelAnimationFrame(reqIdRef.current);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, []);

  // Sync exploded or collapsed layers
  useEffect(() => {
    layerMeshesRef.current.forEach((mesh) => {
      mesh.position.x = exploded ? mesh.userData.defaultX : mesh.userData.collapsedX;
    });
  }, [exploded]);

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col gap-6">
      {/* Top Header & View Mode Switcher */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <span className="text-xs uppercase tracking-wider font-semibold text-rose-400">
            Diapositives 23 à 30 · Histologie & Organisation
          </span>
          <h3 className="text-2xl font-bold text-white mt-1">
            Les 4 Tissus Fondamentaux & L'Organe
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Comment des cellules spécialisées s'associent en tissus, puis en organes complexes comme l'estomac.
          </p>
        </div>

        {/* Switch: Organe Estomac vs Les 4 Tissus */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('organ_stomach')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeTab === 'organ_stomach'
                ? 'bg-rose-500 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            L'Organe : Estomac 3D (4 Tuniques)
          </button>
          <button
            onClick={() => setActiveTab('tissues')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeTab === 'tissues'
                ? 'bg-rose-500 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Les 4 Tissus Fondamentaux
          </button>
        </div>
      </div>

      {activeTab === 'organ_stomach' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* 3D Viewport */}
          <div className="lg:col-span-7 relative min-h-[380px] bg-slate-950 rounded-xl border border-slate-800 overflow-hidden flex flex-col">
            <div className="absolute top-3 left-4 z-10 bg-slate-900/90 border border-slate-800 px-3 py-1.5 rounded-lg text-xs backdrop-blur-md">
              <span className="text-rose-400 font-bold uppercase text-[10px] block">
                Modèle 3D Éclaté
              </span>
              <span className="font-semibold text-white">Coupe des 4 couches de l'estomac</span>
            </div>

            <div className="absolute top-3 right-4 z-10">
              <button
                onClick={() => setExploded(!exploded)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white border border-slate-700"
              >
                {exploded ? 'Assembler les couches' : 'Vue éclatée'}
              </button>
            </div>

            <div ref={containerRef} className="w-full flex-1" />

            {/* Microscopic real photo comparison */}
            <div className="p-3 bg-slate-950/90 border-t border-slate-800 flex items-center gap-3">
              <img
                src={IMAGES.stomach}
                alt="Coupe anatomique de l'estomac"
                className="w-16 h-12 rounded object-cover border border-slate-700"
              />
              <div className="text-[11px] text-slate-400">
                <span className="font-semibold text-slate-200 block">Illustration Anatomique Réelle</span>
                Coupe histologique montrant la muqueuse plissée, la musculeuse et l'innervation entérique.
              </div>
            </div>
          </div>

          {/* Detailed layers description from Slide 30 */}
          <div className="lg:col-span-5 bg-slate-950/60 border border-slate-800/80 rounded-xl p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Activity className="w-4 h-4 text-rose-400" />
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                  Pourquoi l'estomac est un organe ?
                </h4>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/70 p-3 rounded-lg border border-slate-800 mb-4">
                <strong>Définition du cours :</strong> « Ensemble de tissus associés en vue d’assurer une même fonction.
                Dans l’estomac, qui constitue un organe, on trouve du tissu épithélial, du tissu musculaire, du tissu
                conjonctif et du tissu nerveux. »
              </p>

              <div className="space-y-3">
                {STOMACH_ORGAN_EXAMPLE.layers.map((l, idx) => (
                  <div key={idx} className="p-2.5 rounded-lg bg-slate-900/50 border border-slate-800/70 text-xs">
                    <span className="font-bold text-white block mb-0.5">{l.tissue}</span>
                    <p className="text-slate-400 text-[11px] leading-relaxed">{l.role}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-500">
              Synergie fonctionnelle : brassage mécanique + digestion enzymatique acide.
            </div>
          </div>
        </div>
      ) : (
        /* The 4 fundamental human tissues comparator */
        <div className="space-y-6">
          {/* Tissue selector tabs */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {TISSUES.map((t) => (
              <button
                key={t.id}
                onClick={() => setSelectedTissue(t.id)}
                className={`p-3 rounded-xl border text-left transition-all ${
                  selectedTissue === t.id
                    ? 'bg-rose-950/40 border-rose-500 shadow-md'
                    : 'bg-slate-950/60 border-slate-800 hover:bg-slate-900'
                }`}
              >
                <div className="w-2.5 h-2.5 rounded-full mb-1.5" style={{ backgroundColor: t.color }} />
                <h4 className="text-sm font-bold text-white">{t.name.split(' (')[0]}</h4>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">{t.role}</p>
              </button>
            ))}
          </div>

          {/* Active tissue deep dive */}
          {(() => {
            const current = TISSUES.find((t) => t.id === selectedTissue) || TISSUES[0];
            return (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 bg-slate-950/80 border border-slate-800 rounded-xl p-5">
                <div className="md:col-span-8 space-y-4 text-xs">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-rose-400">
                      Tissu Fondamental de l'Organisme
                    </span>
                    <h4 className="text-xl font-bold text-white mt-0.5">{current.name}</h4>
                    <p className="text-slate-300 mt-2 leading-relaxed bg-slate-900/60 p-3 rounded-lg border border-slate-800">
                      {current.description}
                    </p>
                  </div>

                  {current.subtypes && (
                    <div>
                      <h5 className="font-semibold text-slate-200 uppercase tracking-wider text-[11px] mb-2">
                        Les 3 Sous-types Musculaires
                      </h5>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        {current.subtypes.map((sub, i) => (
                          <div key={i} className="p-2.5 rounded-lg bg-slate-900/70 border border-slate-800">
                            <span className="font-bold text-white block text-[11px] mb-1">{sub.name}</span>
                            <p className="text-slate-400 text-[10px] leading-relaxed">{sub.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <h5 className="font-semibold text-slate-200 uppercase tracking-wider text-[11px] mb-1.5">
                      Exemples dans l'organisme (Slide 29)
                    </h5>
                    <div className="flex flex-wrap gap-1.5">
                      {current.examples.map((ex, idx) => (
                        <span key={idx} className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">
                          {ex}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="md:col-span-4 flex flex-col justify-between bg-slate-900/60 p-4 rounded-xl border border-slate-800">
                  <div>
                    <h5 className="font-semibold text-slate-200 uppercase tracking-wider text-[11px] mb-2">
                      Localisation & Rôle
                    </h5>
                    <p className="text-slate-400 text-xs mb-3">
                      <strong className="text-slate-300">Localisation :</strong> {current.location}
                    </p>
                    <p className="text-slate-400 text-xs">
                      <strong className="text-slate-300">Fonction clé :</strong> {current.role}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-800">
                    <img
                      src={IMAGES.tissues}
                      alt="Microscopie des 4 tissus"
                      className="w-full h-24 object-cover rounded-lg border border-slate-700 mb-2"
                    />
                    <span className="text-[10px] text-slate-500 block text-center">
                      Histologie comparée des 4 tissus fondamentaux
                    </span>
                  </div>
                </div>
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
};
