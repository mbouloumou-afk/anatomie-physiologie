import React from 'react';
import { BookOpen, GraduationCap } from 'lucide-react';

interface NavbarProps {
  onOpenGlossary: () => void;
  onOpenSummary: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenGlossary, onOpenSummary }) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-slate-950/85 backdrop-blur-md border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <a href="#" className="text-base sm:text-lg font-bold tracking-tight text-white whitespace-nowrap">
          Anatomie & Physiologie 3D
        </a>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden lg:flex items-center gap-6 text-xs font-semibold text-slate-300">
          <a href="#atlas3d" className="hover:text-teal-400 transition-colors whitespace-nowrap">
            Atlas 3D
          </a>
          <a href="#photos-reelles" className="hover:text-emerald-400 text-emerald-300 transition-colors whitespace-nowrap flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            Vraies Photos
          </a>
          <a href="#organisation" className="hover:text-teal-400 transition-colors whitespace-nowrap">
            Organisation
          </a>
          <a href="#cellule" className="hover:text-teal-400 transition-colors whitespace-nowrap">
            La Cellule 3D
          </a>
          <a href="#transports" className="hover:text-teal-400 transition-colors whitespace-nowrap">
            Transports
          </a>
          <a href="#mitose" className="hover:text-teal-400 transition-colors whitespace-nowrap">
            Mitose
          </a>
          <a href="#tissus" className="hover:text-teal-400 transition-colors whitespace-nowrap">
            Tissus & Organe
          </a>
          <a href="#systemes" className="hover:text-teal-400 transition-colors whitespace-nowrap">
            10 Systèmes
          </a>
          <a href="#quiz" className="hover:text-teal-400 transition-colors whitespace-nowrap">
            QCM
          </a>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenGlossary}
            className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5"
          >
            <BookOpen className="w-3.5 h-3.5 text-teal-400" />
            <span>Glossaire</span>
          </button>
          <button
            onClick={onOpenSummary}
            className="px-3.5 py-1.5 text-xs font-bold text-slate-950 bg-teal-400 hover:bg-teal-300 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 shadow-sm"
          >
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Fiche Synthèse</span>
          </button>
        </div>
      </div>
    </header>
  );
};
