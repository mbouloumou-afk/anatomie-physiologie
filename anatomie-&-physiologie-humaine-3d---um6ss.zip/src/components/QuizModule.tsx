import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { QUIZ_QUESTIONS } from '../data/courseData';
import { CheckCircle2, XCircle, RotateCcw, Award, ArrowRight, HelpCircle } from 'lucide-react';

export const QuizModule: React.FC = () => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);

  const currentQ = QUIZ_QUESTIONS[currentIdx];

  const handleSelectOption = (idx: number) => {
    if (isAnswered) return;
    setSelectedOption(idx);
    setIsAnswered(true);

    const isCorrect = idx === currentQ.correctAnswer;
    if (isCorrect) {
      setScore((prev) => prev + 1);
    }

    setUserAnswers((prev) => [...prev, idx]);
  };

  const handleNext = () => {
    if (currentIdx + 1 < QUIZ_QUESTIONS.length) {
      setCurrentIdx((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setQuizFinished(true);
      // Trigger confetti celebration
      confetti({
        particleCount: 120,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  };

  const handleRestart = () => {
    setCurrentIdx(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setScore(0);
    setQuizFinished(false);
    setUserAnswers([]);
  };

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-2xl p-6 md:p-8 shadow-xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-teal-400">
            Auto-Évaluation & Révision Concours / Examens
          </span>
          <h3 className="text-2xl font-bold text-white mt-1">
            QCM Anatomie & Physiologie Humaine
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Testez vos connaissances sur l'ensemble des diapositives du Professeur Dr M. BADRAOUI.
          </p>
        </div>

        {!quizFinished && (
          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-400">
              Question <strong className="text-teal-400">{currentIdx + 1}</strong> sur {QUIZ_QUESTIONS.length}
            </span>
            <div className="w-24 h-2 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-teal-500 transition-all duration-300"
                style={{ width: `${((currentIdx + 1) / QUIZ_QUESTIONS.length) * 100}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {!quizFinished ? (
        <div className="mt-6 space-y-6">
          {/* Question title */}
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold text-sm shrink-0 mt-0.5">
              {currentIdx + 1}
            </div>
            <h4 className="text-lg font-bold text-white leading-relaxed">
              {currentQ.question}
            </h4>
          </div>

          {/* Options List */}
          <div className="space-y-3">
            {currentQ.options.map((option, idx) => {
              let btnStyle = 'bg-slate-950/70 border-slate-800 hover:border-slate-700 text-slate-300';
              if (isAnswered) {
                if (idx === currentQ.correctAnswer) {
                  btnStyle = 'bg-emerald-950/60 border-emerald-500 text-emerald-200 font-semibold';
                } else if (idx === selectedOption) {
                  btnStyle = 'bg-rose-950/60 border-rose-500 text-rose-200 font-semibold';
                } else {
                  btnStyle = 'bg-slate-950/40 border-slate-900 text-slate-600 opacity-60';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(idx)}
                  disabled={isAnswered}
                  className={`w-full p-4 rounded-xl border text-left text-xs transition-all flex items-center justify-between gap-3 ${btnStyle}`}
                >
                  <span className="leading-relaxed">{option}</span>
                  {isAnswered && idx === currentQ.correctAnswer && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  )}
                  {isAnswered && idx === selectedOption && idx !== currentQ.correctAnswer && (
                    <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Explanation Box */}
          {isAnswered && (
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 animate-in fade-in duration-200">
              <div className="flex items-center gap-2 text-xs font-bold text-teal-400 uppercase tracking-wider mb-1.5">
                <HelpCircle className="w-4 h-4" />
                Explication détaillée du cours
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {currentQ.explanation}
              </p>
              <div className="mt-4 flex justify-end">
                <button
                  onClick={handleNext}
                  className="px-5 py-2.5 bg-teal-500 hover:bg-teal-600 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-2 transition-colors shadow-lg"
                >
                  <span>{currentIdx + 1 === QUIZ_QUESTIONS.length ? 'Terminer et voir le score' : 'Question suivante'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Final Score Card */
        <div className="mt-8 text-center max-w-lg mx-auto py-6 space-y-6">
          <div className="w-20 h-20 rounded-full bg-teal-500/20 text-teal-400 flex items-center justify-center mx-auto shadow-inner">
            <Award className="w-10 h-10" />
          </div>

          <div>
            <span className="text-xs uppercase font-bold tracking-widest text-slate-400">
              Résultat de votre session
            </span>
            <h4 className="text-3xl font-extrabold text-white mt-1">
              Score : <span className="text-teal-400">{score}</span> / {QUIZ_QUESTIONS.length}
            </h4>
            <p className="text-xs text-slate-400 mt-2">
              {score >= 9
                ? 'Excellent travail ! Vous maîtrisez les concepts fondamentaux du cours d’anatomie-physiologie.'
                : score >= 6
                ? 'Bonne maîtrise d’ensemble ! Révisez les quelques détails sur les organites et les transports membranaires.'
                : 'Poursuivez vos révisions avec les modèles 3D et le résumé de cours ci-dessous.'}
            </p>
          </div>

          <button
            onClick={handleRestart}
            className="px-6 py-3 bg-teal-500 hover:bg-teal-600 text-slate-950 font-bold rounded-xl text-xs inline-flex items-center gap-2 shadow-lg transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Recommencer le QCM</span>
          </button>
        </div>
      )}
    </div>
  );
};
