import React, { useState } from 'react';
import { HUMAN_SYSTEMS, SystemInfo, IMAGES } from '../data/courseData';
import {
  Utensils,
  Wind,
  HeartPulse,
  Droplet,
  Activity,
  Cpu,
  Sparkles,
  Heart,
  Shield,
  ShieldCheck,
  Search,
  ArrowRight,
  CheckCircle2,
  X,
  Stethoscope,
  Camera,
} from 'lucide-react';

const iconMap: Record<string, React.ElementType> = {
  Utensils,
  Wind,
  HeartPulse,
  Droplet,
  Activity,
  Cpu,
  Sparkles,
  Heart,
  Shield,
  ShieldCheck,
};

interface SystemsExplorerProps {
  onFocus3DSystem?: (systemId: string) => void;
}

export const SystemsExplorer: React.FC<SystemsExplorerProps> = ({ onFocus3DSystem }) => {
  const [selectedSystem, setSelectedSystem] = useState<SystemInfo | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'Tous les 10 Systèmes' },
    { id: 'nutrition', label: 'Nutrition & Métabolisme' },
    { id: 'ventilation', label: 'Ventilation & Circulation' },
    { id: 'regulation', label: 'Contrôle & Régulation' },
    { id: 'protection', label: 'Défense & Protection' },
  ];

  const filteredSystems = HUMAN_SYSTEMS.filter((sys) => {
    const matchesSearch =
      sys.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sys.organs.some((o) => o.toLowerCase().includes(searchQuery.toLowerCase())) ||
      sys.mainFunction.toLowerCase().includes(searchQuery.toLowerCase());

    if (activeCategory === 'all') return matchesSearch;
    if (activeCategory === 'nutrition') return matchesSearch && (sys.id === 'digestif' || sys.id === 'urinaire');
    if (activeCategory === 'ventilation') return matchesSearch && (sys.id === 'respiratoire' || sys.id === 'cardiovasculaire');
    if (activeCategory === 'regulation') return matchesSearch && (sys.id === 'nerveux' || sys.id === 'endocrinien' || sys.id === 'locomoteur');
    if (activeCategory === 'protection') return matchesSearch && (sys.id === 'tegumentaire' || sys.id === 'lymphatique' || sys.id === 'reproducteur');
    return matchesSearch;
  });

  return (
    <div className="w-full space-y-6">
      {/* Header and Filter Controls */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-teal-400">
            Diapositives 31 à 41 · Les 10 Grands Systèmes Corporels
          </span>
          <h3 className="text-2xl font-bold text-white mt-1">
            Grand Répertoire des Systèmes & Appareils
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            « Ensemble d’organes associés en vue d’assurer une même fonction. »
          </p>
        </div>

        {/* Search input */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Rechercher un organe ou système..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-teal-500 transition-colors"
          />
        </div>
      </div>

      {/* Category Pills / Filter bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
              activeCategory === cat.id
                ? 'bg-teal-500 text-slate-950 font-bold shadow-sm'
                : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* 10 Systems Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {filteredSystems.map((sys) => {
          const IconComp = iconMap[sys.iconName] || Activity;
          return (
            <div
              key={sys.id}
              onClick={() => {
                setSelectedSystem(sys);
                onFocus3DSystem?.(sys.id);
              }}
              className="group cursor-pointer bg-slate-900/70 hover:bg-slate-900 border border-slate-800 hover:border-teal-500/50 rounded-2xl p-5 transition-all duration-200 flex flex-col justify-between shadow-lg hover:shadow-teal-950/20 hover:-translate-y-0.5"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center transition-colors"
                    style={{ backgroundColor: `${sys.color}20`, color: sys.color }}
                  >
                    <IconComp className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider">
                    {sys.category.split(' ')[0]}
                  </span>
                </div>

                <h4 className="text-base font-bold text-white group-hover:text-teal-300 transition-colors">
                  {sys.name}
                </h4>

                <p className="text-xs text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                  {sys.mainFunction}
                </p>

                {/* Organs list preview */}
                <div className="mt-3 pt-3 border-t border-slate-800/80">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">
                    Organes Clés ({sys.organs.length}) :
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {sys.organs.slice(0, 3).map((org, i) => (
                      <span key={i} className="text-[10px] bg-slate-950 text-slate-300 px-1.5 py-0.5 rounded border border-slate-800">
                        {org.split(' ')[0]}
                      </span>
                    ))}
                    {sys.organs.length > 3 && (
                      <span className="text-[10px] text-teal-400 font-medium self-center">
                        +{sys.organs.length - 3}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-teal-400 font-semibold group-hover:translate-x-0.5 transition-transform">
                <span>Examiner les détails</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected System Deep Dive Modal */}
      {selectedSystem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto p-6 md:p-8 shadow-2xl relative">
            <button
              onClick={() => setSelectedSystem(null)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div className="flex items-center gap-3 mb-4">
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center"
                style={{ backgroundColor: `${selectedSystem.color}25`, color: selectedSystem.color }}
              >
                {React.createElement(iconMap[selectedSystem.iconName] || Activity, { className: 'w-6 h-6' })}
              </div>
              <div>
                <span className="text-xs uppercase tracking-wider font-semibold text-teal-400">
                  {selectedSystem.category}
                </span>
                <h3 className="text-2xl font-bold text-white">{selectedSystem.name}</h3>
              </div>
            </div>

            {/* Content Sections */}
            <div className="space-y-4 text-xs mt-6">
              {/* Authentic Real Photo Banner if available */}
              {(() => {
                let photoSrc: string | null = null;
                let photoLabel = '';
                if (selectedSystem.id === 'cardiovasculaire') {
                  photoSrc = IMAGES.realHeart;
                  photoLabel = 'Vraie Pièce Anatomique : Cœur humain et système coronaire macro';
                } else if (selectedSystem.id === 'respiratoire') {
                  photoSrc = IMAGES.realLungs;
                  photoLabel = 'Vraie Lame Histologique : Alvéoles pulmonaires et capillaires sanguins (x 400)';
                } else if (selectedSystem.id === 'nerveux') {
                  photoSrc = IMAGES.realBrain;
                  photoLabel = 'Vrai Spécimen Médical : Encéphale, cortex cérébral et tronc cérébral';
                } else if (selectedSystem.id === 'tegumentaire') {
                  photoSrc = IMAGES.realSkin;
                  photoLabel = 'Vraie Lame Histologique : Coupe de la peau, derme, épiderme et follicule pileux';
                } else if (selectedSystem.id === 'digestif') {
                  photoSrc = IMAGES.stomach;
                  photoLabel = 'Vraie Coupe Anatomique : Les 4 tuniques tissulaires de l’estomac';
                }

                if (!photoSrc) return null;

                return (
                  <div className="p-3.5 bg-slate-950 border border-emerald-500/30 rounded-xl flex flex-col sm:flex-row items-center gap-4">
                    <img
                      src={photoSrc}
                      alt={photoLabel}
                      className="w-full sm:w-36 h-24 object-cover rounded-lg border border-slate-700 shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div className="space-y-1">
                      <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-400 flex items-center gap-1.5">
                        <Camera className="w-3.5 h-3.5" />
                        Photographie Scientifique Réelle
                      </span>
                      <h5 className="font-bold text-white text-xs">{photoLabel}</h5>
                      <p className="text-slate-400 text-[11px] leading-relaxed">
                        Confrontation avec la réalité biologique enseignée dans les travaux dirigés (TD) et travaux pratiques (TP) de l’UM6SS.
                      </p>
                    </div>
                  </div>
                );
              })()}

              {/* Function & Role */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                  <h4 className="font-bold text-white uppercase tracking-wider text-[11px] mb-1.5 flex items-center gap-1.5">
                    <Activity className="w-3.5 h-3.5 text-teal-400" />
                    Fonction Principale
                  </h4>
                  <p className="text-slate-300 leading-relaxed">{selectedSystem.mainFunction}</p>
                </div>

                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                  <h4 className="font-bold text-white uppercase tracking-wider text-[11px] mb-1.5 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                    Mécanismes Physiologiques
                  </h4>
                  <p className="text-slate-300 leading-relaxed">{selectedSystem.physiologicalRole}</p>
                </div>
              </div>

              {/* Complete organs list directly transcribed from the slide */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <h4 className="font-bold text-white uppercase tracking-wider text-[11px] mb-2">
                  Composition Anatomique Complète (Diapositives du Pr. Badraoui)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                  {selectedSystem.organs.map((org, i) => (
                    <div key={i} className="flex items-center gap-2 p-2 rounded-lg bg-slate-900 border border-slate-800/80">
                      <CheckCircle2 className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                      <span className="text-slate-200 font-medium">{org}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Interdependence & Clinical Relevance */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800">
                  <h4 className="font-bold text-teal-300 uppercase tracking-wider text-[11px] mb-1.5">
                    Coopération avec les autres systèmes
                  </h4>
                  <p className="text-slate-300 leading-relaxed">{selectedSystem.interdependence}</p>
                </div>

                <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800">
                  <h4 className="font-bold text-rose-300 uppercase tracking-wider text-[11px] mb-1.5 flex items-center gap-1.5">
                    <Stethoscope className="w-3.5 h-3.5 text-rose-400" />
                    Pertinence Clinique & Pathologies
                  </h4>
                  <p className="text-slate-300 leading-relaxed">{selectedSystem.clinicalRelevance}</p>
                </div>
              </div>
            </div>

            {/* Modal action */}
            <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
              <span className="text-slate-500 text-[11px]">
                Filière SI/RR · Faculté Mohammed VI des Sciences Infirmières
              </span>
              <button
                onClick={() => setSelectedSystem(null)}
                className="px-4 py-2 bg-teal-500 hover:bg-teal-600 text-slate-950 font-bold rounded-xl text-xs transition-colors"
              >
                Fermer la fiche
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
