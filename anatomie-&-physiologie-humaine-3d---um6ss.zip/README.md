# Anatomie & Physiologie Humaine 3D - UM6SS

Plateforme interactive d'apprentissage en 3D et atlas photographique réel du cours d'Anatomie et Physiologie Humaine.
- **Université** : Université Mohammed VI des Sciences et de la Santé (UM6SS) - Marrakech
- **Faculté** : Faculté Mohammed VI des Sciences Infirmières et des Professions de la Santé
- **Filière** : SI / RR (IP - IAR - IBO - KINE) · Semestre 1
- **Enseignant** : Dr BADRAOUI Marouane (2026-2027)

---

## Fonctionnalités
- **Atlas 3D du Corps Humain** avec calques (peau, squelette, muscles, organes vitaux, vaisseaux sanguins, système nerveux).
- **Ultrastructure 3D de la Cellule Eucaryote** avec exploration détaillée de tous les organites.
- **Simulateur 3D des Transports Membranaires** (diffusion simple, facilitée, transport actif ATP, endocytose/exocytose).
- **Simulateur 3D de la Mitose & Différenciation Cellulaire** (Interphase G1/S/G2, Prophase, Métaphase, Anaphase, Télophase).
- **Coupe 3D de l'Estomac & Histologie des 4 Tissus**.
- **Grand Répertoire des 10 Systèmes Corporels**.
- **Galerie de Photographies Réelles & Microscopie Électronique (TEM)**.
- **QCM d'auto-évaluation** avec correction détaillée.
- **Glossaire médical et Fiche de révision imprimable**.

---

## 🚀 Guide de mise en ligne sur GitHub & Déploiement

### Étape 1 : Initialiser Git localement (si ce n'est pas déjà fait)
Dans le terminal de votre projet :
```bash
git init
git add .
git commit -m "Initial commit - Anatomie & Physiologie 3D UM6SS"
```

### Étape 2 : Créer un nouveau dépôt sur GitHub
1. Rendez-vous sur [github.com](https://github.com) et connectez-vous.
2. Cliquez sur le bouton vert **« New »** (Nouveau dépôt).
3. Nommez le dépôt (par exemple : `anatomie-physiologie-3d`).
4. Choisissez **Public** (recommandé pour GitHub Pages gratuit).
5. Ne cochez pas « Add a README file » (vous l'avez déjà).
6. Cliquez sur **« Create repository »**.

### Étape 3 : Lier votre projet local à GitHub et pousser le code
Remplacez `VOTRE_PSEUDO` par votre nom d'utilisateur GitHub :
```bash
git branch -M main
git remote add origin https://github.com/VOTRE_PSEUDO/anatomie-physiologie-3d.git
git push -u origin main
```

---

## 🌐 Déploiement en ligne (Serveur gratuit 24/7)

### Option A : Déploiement automatique avec GitHub Pages (Inclus !)
Le fichier `.github/workflows/deploy.yml` est déjà configuré dans le projet.
1. Sur votre dépôt GitHub, allez dans **Settings** (Paramètres) > **Pages** (dans le menu de gauche).
2. Dans la section **Build and deployment** :
   - Sous **Source**, sélectionnez **GitHub Actions**.
3. C'est tout ! Dès que vous poussez sur `main`, GitHub compile et héberge votre site gratuitement à l'adresse :
   `https://VOTRE_PSEUDO.github.io/anatomie-physiologie-3d/`

### Option B : Déploiement en 1 clic sur Vercel (Recommandé & Ultra-rapide)
1. Allez sur [vercel.com](https://vercel.com) et connectez-vous avec votre compte GitHub.
2. Cliquez sur **« Add New Project »** et sélectionnez votre dépôt `anatomie-physiologie-3d`.
3. Cliquez simplement sur **« Deploy »** sans rien changer.
4. Votre site sera instantanément en ligne avec une URL sécurisée en HTTPS (ex: `https://anatomie-physiologie-3d.vercel.app`).
